"""
ANALOG & HYBRID COMPUTING MODULE FOR SENEMOSÌA
Continuous dynamical systems, mixed-signal processing, and analog neural networks
"""

import numpy as np
from typing import List, Dict, Tuple, Callable
from dataclasses import dataclass
from scipy.integrate import odeint, solve_ivp
import warnings
warnings.filterwarnings('ignore')


# ============================================================================
# CONTINUOUS DYNAMICAL SYSTEMS
# ============================================================================

@dataclass
class DynamicalSystem:
    """Base class for continuous differential equations"""
    
    state: np.ndarray  # x(t): state vector
    time: float        # Current time t
    
    def dx_dt(self, x: np.ndarray, t: float) -> np.ndarray:
        """Time derivative: dx/dt = f(x, t). Override in subclass."""
        raise NotImplementedError


class VanDerPolOscillator(DynamicalSystem):
    """
    Van der Pol oscillator: nonlinear limit-cycle oscillation
    d²x/dt² - μ(1-x²)dx/dt + x = 0
    
    Used in analog computing for signal processing and pattern generation
    """
    
    def __init__(self, mu: float = 1.0):
        self.mu = mu
        self.state = np.array([0.1, 0.1])  # [x, dx/dt]
        self.time = 0
        self.trajectory = []
    
    def dx_dt(self, x: np.ndarray, t: float) -> np.ndarray:
        """Van der Pol dynamics"""
        x1, x2 = x
        dx1_dt = x2
        dx2_dt = self.mu * (1 - x1**2) * x2 - x1
        return np.array([dx1_dt, dx2_dt])
    
    def integrate(self, t_span: Tuple[float, float], num_points: int = 1000):
        """Integrate using RK45"""
        t_eval = np.linspace(t_span[0], t_span[1], num_points)
        
        sol = solve_ivp(self.dx_dt, t_span, self.state, t_eval=t_eval, method='RK45')
        
        self.trajectory = sol.y.T
        self.time = sol.t
        return sol


class HodgkinHuxleyNeuron(DynamicalSystem):
    """
    Hodgkin-Huxley model: realistic neuronal membrane dynamics
    Describes action potential generation in squid giant axon
    
    Equations:
    - C_m dV/dt = -I_Na - I_K - I_L + I_ext
    - dm/dt = α_m(V)(1-m) - β_m(V)m  [similar for h, n]
    """
    
    def __init__(self, V_rest: float = -65):
        # Membrane potential and gating variables
        self.state = np.array([V_rest, 0.05, 0.6, 0.32])  # [V, m, h, n]
        self.time = 0
        
        # Biophysical parameters
        self.C_m = 1.0        # Membrane capacitance (μF/cm²)
        self.g_Na = 120.0     # Na conductance (mS/cm²)
        self.g_K = 36.0       # K conductance
        self.g_L = 0.3        # Leak conductance
        self.E_Na = 50.0      # Na reversal potential (mV)
        self.E_K = -77.0      # K reversal potential
        self.E_L = -54.4      # Leak reversal potential
    
    def alpha_m(self, V):
        return 0.1 * (V + 40) / (1 - np.exp(-(V + 40) / 10))
    
    def beta_m(self, V):
        return 4 * np.exp(-(V + 65) / 18)
    
    def alpha_h(self, V):
        return 0.07 * np.exp(-(V + 65) / 20)
    
    def beta_h(self, V):
        return 1 / (1 + np.exp(-(V + 35) / 10))
    
    def alpha_n(self, V):
        return 0.01 * (V + 55) / (1 - np.exp(-(V + 55) / 10))
    
    def beta_n(self, V):
        return 0.125 * np.exp(-(V + 65) / 80)
    
    def dx_dt(self, x: np.ndarray, t: float, I_ext: float = 10) -> np.ndarray:
        """Hodgkin-Huxley equations"""
        V, m, h, n = x
        
        # Ionic currents
        I_Na = self.g_Na * m**3 * h * (V - self.E_Na)
        I_K = self.g_K * n**4 * (V - self.E_K)
        I_L = self.g_L * (V - self.E_L)
        
        # Voltage equation
        dV_dt = (I_ext - I_Na - I_K - I_L) / self.C_m
        
        # Gating variables
        dm_dt = self.alpha_m(V) * (1 - m) - self.beta_m(V) * m
        dh_dt = self.alpha_h(V) * (1 - h) - self.beta_h(V) * h
        dn_dt = self.alpha_n(V) * (1 - n) - self.beta_n(V) * n
        
        return np.array([dV_dt, dm_dt, dh_dt, dn_dt])


# ============================================================================
# ANALOG CIRCUITS & COMPUTATION
# ============================================================================

class OpAmpCircuit:
    """
    Operational amplifier based analog computer
    Implements basic analog operations: integration, summation, differentiation
    """
    
    def __init__(self, gain: float = 1.0, bandwidth: float = 1e5):
        self.gain = gain              # Open-loop gain
        self.bandwidth = bandwidth    # -3dB bandwidth (Hz)
        self.tau_opamp = 1 / (2 * np.pi * bandwidth)  # Time constant
        self.v_in = 0
        self.v_out = 0
        self.slew_rate = 0.5          # V/μs (finite slew rate)
    
    def integrator(self, v_in: float, R: float = 1e3, C: float = 1e-6, dt: float = 1e-6):
        """
        Integrator: V_out = -1/(RC) ∫ V_in dt
        """
        dv_out = -(v_in / (R * C)) * dt
        
        # Apply slew rate limiting
        max_change = self.slew_rate * dt
        dv_out = np.clip(dv_out, -max_change, max_change)
        
        self.v_out += dv_out
        return self.v_out
    
    def summer(self, inputs: List[float], weights: List[float] = None) -> float:
        """
        Summing amplifier: V_out = -Σ(w_i * V_i)
        """
        if weights is None:
            weights = [1.0] * len(inputs)
        
        self.v_out = -self.gain * np.sum([w * v for w, v in zip(weights, inputs)])
        return self.v_out
    
    def differentiator(self, v_in: float, R: float = 1e3, C: float = 1e-6, dt: float = 1e-6):
        """
        Differentiator: V_out = -RC dV_in/dt
        (Note: susceptible to noise amplification)
        """
        dv_in_dt = (v_in - self.v_in) / dt
        self.v_out = -R * C * dv_in_dt * self.gain
        self.v_in = v_in
        return self.v_out


class AnalogNeuralNetwork:
    """
    Analog Neural Network: neurons as continuous nonlinear dynamical systems
    Uses sigmoid activation as continuous approximation of neural firing rate
    """
    
    def __init__(self, layer_sizes: List[int], time_constant: float = 0.1):
        self.layer_sizes = layer_sizes
        self.time_constant = time_constant
        
        # Network state: membrane potentials
        self.states = [np.zeros(size) for size in layer_sizes]
        
        # Synaptic weights
        self.weights = []
        for i in range(len(layer_sizes) - 1):
            W = np.random.randn(layer_sizes[i], layer_sizes[i+1]) * 0.1
            self.weights.append(W)
        
        # Biases
        self.biases = [np.random.randn(size) * 0.01 for size in layer_sizes[1:]]
    
    def sigmoid(self, x: np.ndarray) -> np.ndarray:
        """Continuous sigmoid: smooth firing rate"""
        return 1 / (1 + np.exp(-x))
    
    def sigmoid_derivative(self, x: np.ndarray) -> np.ndarray:
        """Derivative for gradient-based learning"""
        s = self.sigmoid(x)
        return s * (1 - s)
    
    def dynamics(self, x: np.ndarray, t: float, layer_idx: int) -> np.ndarray:
        """
        ODE for neural layer:
        τ dV/dt = -V + Σ(W * f(V_prev)) + b
        where f is sigmoid (smooth firing rate)
        """
        # Input from previous layer
        if layer_idx == 0:
            input_current = x  # External input
        else:
            prev_output = self.sigmoid(self.states[layer_idx - 1])
            input_current = self.weights[layer_idx - 1] @ prev_output + self.biases[layer_idx - 1]
        
        # Membrane dynamics
        dV_dt = (-self.states[layer_idx] + input_current) / self.time_constant
        return dV_dt
    
    def forward(self, x_input: np.ndarray, num_steps: int = 100, dt: float = 0.001):
        """Forward pass: iterate continuous dynamics"""
        self.states[0] = x_input
        
        for step in range(num_steps):
            for layer_idx in range(1, len(self.layer_sizes)):
                # Update membrane potentials
                prev_output = self.sigmoid(self.states[layer_idx - 1])
                input_current = self.weights[layer_idx - 1] @ prev_output + self.biases[layer_idx - 1]
                self.states[layer_idx] += dt * (-self.states[layer_idx] + input_current) / self.time_constant
        
        # Output: firing rates
        output = self.sigmoid(self.states[-1])
        return output


# ============================================================================
# HYBRID DIGITAL-ANALOG SYSTEMS
# ============================================================================

class HybridSystem:
    """
    Hybrid system combining discrete (digital) and continuous (analog) dynamics
    Example: digital controller + analog plant
    """
    
    def __init__(self, plant_dynamics: Callable, controller_update_rate: float = 1000):
        self.plant_dynamics = plant_dynamics  # Continuous plant ODE
        self.controller_update_rate = controller_update_rate  # Hz
        self.dt_digital = 1 / controller_update_rate
        
        self.plant_state = np.array([0.0])
        self.controller_state = 0.0
        self.time = 0
        self.trajectory = []
    
    def digital_controller(self, measurement: float) -> float:
        """
        Digital controller: simple PID
        u = K_p * e + K_i * ∫e + K_d * de/dt
        """
        setpoint = 1.0
        error = setpoint - measurement
        
        K_p, K_i, K_d = 1.0, 0.1, 0.5
        
        control_signal = K_p * error
        self.controller_state += K_i * error * self.dt_digital
        control_signal += self.controller_state
        
        return control_signal
    
    def integrate(self, t_span: Tuple[float, float], num_steps: int = 1000):
        """Hybrid integration: alternating digital-analog"""
        t_digital = np.arange(t_span[0], t_span[1], self.dt_digital)
        
        for t_dig in t_digital:
            # Digital: control update
            measurement = self.plant_state[0]
            control_signal = self.digital_controller(measurement)
            
            # Analog: plant dynamics
            def plant_with_control(x, t):
                return self.plant_dynamics(x, t, control_signal)
            
            # Integrate plant for dt_digital
            t_analog = np.linspace(t_dig, t_dig + self.dt_digital, 10)
            sol = solve_ivp(plant_with_control, [t_dig, t_dig + self.dt_digital], 
                           self.plant_state, t_eval=t_analog, method='RK45')
            
            self.plant_state = sol.y[:, -1]
            self.trajectory.append(self.plant_state.copy())
            self.time = t_dig
        
        return np.array(self.trajectory)


# ============================================================================
# ANALOG-SENEMOSÌA BRIDGE
# ============================================================================

class AnalogSenemosyaBridge:
    """
    Bridge between analog computation and Senemosìa's 6D harmonic space
    Maps continuous dynamics to geometric coordinates
    """
    
    def __init__(self):
        self.phi = (1 + np.sqrt(5)) / 2
    
    def trajectory_to_geometric(self, trajectory: np.ndarray) -> np.ndarray:
        """
        Map continuous trajectory → 6D coordinates
        Using Fourier harmonics at golden-ratio frequencies
        """
        coords_6d = np.zeros(6)
        
        if len(trajectory) == 0:
            return coords_6d
        
        # Compute FFT of trajectory
        fft_vals = np.fft.fft(trajectory, axis=0)
        freqs = np.fft.fftfreq(len(trajectory))
        
        for i in range(6):
            # Golden-ratio harmonic frequencies
            harmonic = self.phi ** (i - 2)
            
            # Find energy at this harmonic
            target_freq_idx = int(harmonic * len(trajectory)) % len(trajectory)
            coords_6d[i] = np.abs(fft_vals[target_freq_idx]) / (len(trajectory) + 1)
        
        # Normalize
        norm = np.linalg.norm(coords_6d)
        if norm > 0:
            coords_6d /= norm
        
        return coords_6d
    
    def analog_state_to_senemosya(self, state_vector: np.ndarray) -> Dict[str, any]:
        """Map continuous analog state → Senemosìa harmonic state"""
        # Treat state values as trajectory points
        trajectory = np.tile(state_vector, (100, 1)) if len(state_vector.shape) == 1 else state_vector
        
        coords_6d = self.trajectory_to_geometric(trajectory)
        
        # Energy (L2 norm) as magnitude
        energy = np.linalg.norm(state_vector)
        
        return {
            'coords_6d': coords_6d,
            'state_vector': state_vector,
            'energy': energy,
            'magnitude': np.exp(-energy / 10)  # Normalized
        }


# ============================================================================
# BENCHMARKING
# ============================================================================

def benchmark_analog_hybrid():
    """Benchmark analog and hybrid systems"""
    results = {}
    
    # Van der Pol Oscillator
    print("Benchmarking Van der Pol Oscillator...")
    vdp = VanDerPolOscillator(mu=1.0)
    sol = vdp.integrate((0, 100), num_points=10000)
    
    results['van_der_pol'] = {
        'type': 'Nonlinear limit-cycle oscillator',
        'trajectory_length': len(sol.t),
        'applications': 'Signal processing, frequency generation',
        'energy_efficiency': 'Continuous (no discretization loss)'
    }
    
    # Hodgkin-Huxley Neuron
    print("Benchmarking Hodgkin-Huxley Model...")
    hh = HodgkinHuxleyNeuron()
    
    def hh_dynamics(x, t):
        return hh.dx_dt(x, t, I_ext=20)
    
    t_eval = np.linspace(0, 100, 10000)
    sol_hh = solve_ivp(hh_dynamics, [0, 100], hh.state, t_eval=t_eval, method='RK45')
    
    # Count action potentials (spikes)
    V = sol_hh.y[0]
    spikes = np.sum(np.diff(V > 0).astype(int) == 1)
    
    results['hodgkin_huxley'] = {
        'model': 'Biophysical neuronal model',
        'action_potentials': spikes,
        'biological_realism': 'High (matches squid axon data)',
        'computational_cost': 'Higher than spiking models'
    }
    
    # Analog Neural Network
    print("Benchmarking Analog Neural Network...")
    ann = AnalogNeuralNetwork([10, 20, 5])
    
    x_test = np.random.randn(10) * 0.1
    output = ann.forward(x_test, num_steps=100, dt=0.001)
    
    results['analog_nn'] = {
        'architecture': '10→20→5',
        'activation': 'Continuous sigmoid',
        'output_shape': output.shape,
        'computation_type': 'Continuous dynamics (ODE)'
    }
    
    # Hybrid System (digital control + analog plant)
    print("Benchmarking Hybrid System...")
    
    def plant_dynamics(x, t, u):
        # Simple first-order plant: dx/dt = -x + u
        return np.array([-x[0] + u])
    
    hybrid = HybridSystem(plant_dynamics, controller_update_rate=100)
    traj = hybrid.integrate((0, 10), num_steps=1000)
    
    results['hybrid_system'] = {
        'composition': 'Digital controller + Analog plant',
        'controller_rate': '100 Hz',
        'plant_model': 'First-order continuous',
        'final_trajectory': traj[-1] if len(traj) > 0 else None
    }
    
    return results


if __name__ == "__main__":
    print("Analog & Hybrid Computing Module for Senemosìa")
    print("=" * 60)
    
    # Test Van der Pol
    print("\nVan der Pol Oscillator:")
    vdp = VanDerPolOscillator(mu=2.0)
    sol = vdp.integrate((0, 20), num_points=500)
    print(f"Generated trajectory with {len(sol.t)} points")
    
    # Test Hodgkin-Huxley
    print("\nHodgkin-Huxley Neuron:")
    hh = HodgkinHuxleyNeuron()
    print(f"Initial state: V={hh.state[0]:.2f}mV")
    
    # Test OpAmp
    print("\nOp-Amp Integrator:")
    opamp = OpAmpCircuit()
    v_out = opamp.integrator(v_in=1.0, R=1e3, C=1e-6)
    print(f"Integrated: V_out = {v_out:.6f}V")
    
    # Test Analog NN
    print("\nAnalog Neural Network:")
    ann = AnalogNeuralNetwork([5, 10, 3])
    x_input = np.array([0.1, -0.2, 0.3, -0.1, 0.2])
    output = ann.forward(x_input, num_steps=50)
    print(f"Output: {output}")
    
    # Bridge
    bridge = AnalogSenemosyaBridge()
    state_senemosya = bridge.analog_state_to_senemosya(output)
    print(f"Senemosìa mapping: coords={state_senemosya['coords_6d']}, magnitude={state_senemosya['magnitude']:.4f}")
