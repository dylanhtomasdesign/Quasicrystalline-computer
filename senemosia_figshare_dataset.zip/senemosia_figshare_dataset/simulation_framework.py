"""
Unconventional Computing Models Simulator
Framework for prototyping and comparing alternative computational architectures
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Optional
import numpy as np
from collections import defaultdict
import time


@dataclass
class ExecutionMetrics:
    """Track execution performance and behavior"""
    steps: int
    time_elapsed: float
    memory_accesses: int
    state_transitions: int
    halted: bool
    output: Any
    trace: List[Dict[str, Any]]


class ComputationModel(ABC):
    """Abstract base class for computation models"""
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.metrics = None
        
    @abstractmethod
    def initialize(self, program: str, input_data: Any = None):
        """Initialize the model with a program"""
        pass
    
    @abstractmethod
    def step(self) -> bool:
        """Execute one step. Return False if halted."""
        pass
    
    @abstractmethod
    def run(self, max_steps: int = 10000) -> ExecutionMetrics:
        """Run until halt or max_steps reached"""
        pass
    
    @abstractmethod
    def get_state(self) -> Dict[str, Any]:
        """Return current machine state"""
        pass


class TuringMachine(ComputationModel):
    """Classical deterministic Turing machine (baseline reference)"""
    
    def __init__(self):
        super().__init__(
            "Turing Machine",
            "Classical single-tape Turing machine with finite state automaton"
        )
        self.tape = {}  # Dictionary for infinite tape
        self.head_position = 0
        self.state = None
        self.states = {}
        self.start_state = None
        self.halt_states = set()
        self.output = []
        self.halted = False
        self.trace = []
        
    def initialize(self, program: str, input_data: str = ""):
        """
        Initialize with TM program in format:
        state,read_sym -> write_sym,move,next_state
        Lines starting with # are comments
        START: state_name
        HALT: state1,state2,...
        """
        self.tape = {i: c for i, c in enumerate(input_data)}
        self.head_position = 0
        self.output = []
        self.halted = False
        self.trace = []
        self.states = {}
        
        for line in program.strip().split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if line.startswith('START:'):
                self.start_state = line.split(':')[1].strip()
                self.state = self.start_state
            elif line.startswith('HALT:'):
                self.halt_states = set(s.strip() for s in line.split(':')[1].split(','))
            else:
                # Parse transition: state,read -> write,move,next_state
                if '->' in line:
                    left, right = line.split('->')
                    state_sym = left.split(',')
                    state, read_sym = state_sym[0].strip(), state_sym[1].strip()
                    
                    parts = right.split(',')
                    write_sym = parts[0].strip()
                    move = parts[1].strip()  # L or R
                    next_state = parts[2].strip()
                    
                    if state not in self.states:
                        self.states[state] = {}
                    self.states[state][read_sym] = (write_sym, move, next_state)
    
    def step(self) -> bool:
        """Execute one step"""
        if self.halted or self.state in self.halt_states:
            self.halted = True
            return False
        
        read_sym = self.tape.get(self.head_position, '_')
        
        if self.state not in self.states or read_sym not in self.states[self.state]:
            self.halted = True
            return False
        
        write_sym, move, next_state = self.states[self.state][read_sym]
        
        self.tape[self.head_position] = write_sym
        self.output.append(write_sym)
        
        if move == 'R':
            self.head_position += 1
        elif move == 'L':
            self.head_position -= 1
        
        self.trace.append({
            'state': self.state,
            'read': read_sym,
            'write': write_sym,
            'move': move,
            'head_pos': self.head_position,
            'tape_snapshot': dict(self.tape)
        })
        
        self.state = next_state
        return True
    
    def run(self, max_steps: int = 10000) -> ExecutionMetrics:
        """Execute until halt"""
        start_time = time.time()
        steps = 0
        
        while steps < max_steps and self.step():
            steps += 1
        
        return ExecutionMetrics(
            steps=steps,
            time_elapsed=time.time() - start_time,
            memory_accesses=len(self.trace),
            state_transitions=len(set(t['state'] for t in self.trace)),
            halted=self.halted,
            output=''.join(self.output),
            trace=self.trace
        )
    
    def get_state(self) -> Dict[str, Any]:
        return {
            'current_state': self.state,
            'head_position': self.head_position,
            'tape': dict(self.tape),
            'output': ''.join(self.output)
        }


class GeometricComputationModel(ComputationModel):
    """
    Novel model: computation via geometric state transformations
    - State represented as point in high-dimensional space
    - Operations are rotations/projections in that space
    - Programs specify geometric transformations
    """
    
    def __init__(self, dimensions: int = 6):
        super().__init__(
            "Geometric Computation",
            f"Computation via geometric transformations in {dimensions}D space"
        )
        self.dimensions = dimensions
        self.state_vector = np.zeros(dimensions)
        self.operations = []
        self.operation_idx = 0
        self.halted = False
        self.output = []
        self.trace = []
        self.memory = {}  # Named symbolic registers
        
    def initialize(self, program: str, input_data: Any = None):
        """
        Initialize with geometric program format:
        ROTATE: axis1,axis2,angle
        PROJECT: onto_dimension
        SCALE: factor
        THRESHOLD: dimension,value -> output
        """
        self.state_vector = np.zeros(self.dimensions)
        self.operations = []
        self.operation_idx = 0
        self.halted = False
        self.output = []
        self.trace = []
        self.memory = {}
        
        # Initialize state from input
        if input_data:
            if isinstance(input_data, (list, tuple)):
                for i, val in enumerate(input_data[:self.dimensions]):
                    self.state_vector[i] = float(val)
            elif isinstance(input_data, (int, float)):
                self.state_vector[0] = float(input_data)
        
        for line in program.strip().split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            self.operations.append(line)
    
    def _rotation_matrix(self, d1: int, d2: int, angle: float) -> np.ndarray:
        """Create rotation matrix in d1-d2 plane"""
        R = np.eye(self.dimensions)
        c, s = np.cos(angle), np.sin(angle)
        R[d1, d1] = c
        R[d1, d2] = -s
        R[d2, d1] = s
        R[d2, d2] = c
        return R
    
    def step(self) -> bool:
        """Execute one geometric operation"""
        if self.halted or self.operation_idx >= len(self.operations):
            self.halted = True
            return False
        
        op = self.operations[self.operation_idx]
        self.operation_idx += 1
        
        old_state = self.state_vector.copy()
        
        if op.startswith('ROTATE:'):
            parts = op.split(':')[1].split(',')
            d1, d2 = int(parts[0].strip()), int(parts[1].strip())
            angle = float(parts[2].strip())
            R = self._rotation_matrix(d1, d2, angle)
            self.state_vector = R @ self.state_vector
            
        elif op.startswith('PROJECT:'):
            dim = int(op.split(':')[1].strip())
            self.state_vector[dim:] = 0
            
        elif op.startswith('SCALE:'):
            factor = float(op.split(':')[1].strip())
            self.state_vector *= factor
            
        elif op.startswith('THRESHOLD:'):
            parts = op.split(':')[1].split('->')
            dim_threshold = parts[0].split(',')
            dim = int(dim_threshold[0].strip())
            threshold = float(dim_threshold[1].strip())
            if self.state_vector[dim] > threshold:
                self.output.append(1)
            else:
                self.output.append(0)
        
        elif op.startswith('NORM'):
            magnitude = np.linalg.norm(self.state_vector)
            if magnitude > 0:
                self.state_vector /= magnitude
        
        self.trace.append({
            'operation': op,
            'state_before': old_state.copy(),
            'state_after': self.state_vector.copy(),
            'magnitude': np.linalg.norm(self.state_vector)
        })
        
        return True
    
    def run(self, max_steps: int = 10000) -> ExecutionMetrics:
        """Execute all operations"""
        start_time = time.time()
        steps = 0
        
        while steps < max_steps and self.step():
            steps += 1
        
        return ExecutionMetrics(
            steps=steps,
            time_elapsed=time.time() - start_time,
            memory_accesses=len(self.trace),
            state_transitions=len(self.operations),
            halted=self.halted,
            output=self.output,
            trace=self.trace
        )
    
    def get_state(self) -> Dict[str, Any]:
        return {
            'state_vector': self.state_vector.tolist(),
            'magnitude': float(np.linalg.norm(self.state_vector)),
            'operation_index': self.operation_idx,
            'output': self.output
        }


class ResonanceComputationModel(ComputationModel):
    """
    Novel model: computation via interference patterns
    - Multiple "wave" states interfere constructively/destructively
    - Information encoded in phase relationships
    - Operations are harmonic transformations
    """
    
    def __init__(self, num_modes: int = 8):
        super().__init__(
            "Resonance Computation",
            f"Computation via {num_modes} harmonic modes and interference patterns"
        )
        self.num_modes = num_modes
        self.modes = np.zeros(num_modes, dtype=complex)  # Phase and amplitude
        self.operations = []
        self.operation_idx = 0
        self.halted = False
        self.output = []
        self.trace = []
        
    def initialize(self, program: str, input_data: Any = None):
        """
        Initialize with resonance program:
        EXCITE: mode,frequency,phase
        INTERFERE: mode1,mode2
        MEASURE: mode,threshold -> output
        COUPLE: mode1,mode2,coupling_strength
        """
        self.modes = np.zeros(self.num_modes, dtype=complex)
        self.operations = []
        self.operation_idx = 0
        self.halted = False
        self.output = []
        self.trace = []
        
        # Initialize from input
        if input_data:
            if isinstance(input_data, (list, tuple)):
                for i, val in enumerate(input_data[:self.num_modes]):
                    self.modes[i] = complex(val)
            elif isinstance(input_data, (int, float)):
                self.modes[0] = complex(input_data)
        
        for line in program.strip().split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            self.operations.append(line)
    
    def step(self) -> bool:
        """Execute one harmonic operation"""
        if self.halted or self.operation_idx >= len(self.operations):
            self.halted = True
            return False
        
        op = self.operations[self.operation_idx]
        self.operation_idx += 1
        
        old_modes = self.modes.copy()
        
        if op.startswith('EXCITE:'):
            parts = op.split(':')[1].split(',')
            mode = int(parts[0].strip())
            freq = float(parts[1].strip())
            phase = float(parts[2].strip())
            self.modes[mode] += np.exp(1j * phase) * freq
            
        elif op.startswith('INTERFERE:'):
            parts = op.split(':')[1].split(',')
            m1, m2 = int(parts[0].strip()), int(parts[1].strip())
            # Constructive/destructive interference
            interference = self.modes[m1] * np.conj(self.modes[m2])
            self.modes[m1] += interference * 0.1
            
        elif op.startswith('MEASURE:'):
            parts = op.split(':')[1].split('->')
            mode = int(parts[0].split(',')[0].strip())
            threshold = float(parts[0].split(',')[1].strip())
            amplitude = abs(self.modes[mode])
            self.output.append(1 if amplitude > threshold else 0)
            
        elif op.startswith('COUPLE:'):
            parts = op.split(':')[1].split(',')
            m1, m2 = int(parts[0].strip()), int(parts[1].strip())
            coupling = float(parts[2].strip())
            # Couple oscillator modes
            temp = self.modes[m1] * coupling
            self.modes[m1] = self.modes[m1] * (1 - coupling) + self.modes[m2] * coupling
            self.modes[m2] = self.modes[m2] * (1 - coupling) + temp
        
        elif op.startswith('NORMALIZE'):
            total_energy = np.sum(np.abs(self.modes)**2)
            if total_energy > 0:
                self.modes /= np.sqrt(total_energy)
        
        self.trace.append({
            'operation': op,
            'modes_before': old_modes.copy(),
            'modes_after': self.modes.copy(),
            'total_energy': float(np.sum(np.abs(self.modes)**2))
        })
        
        return True
    
    def run(self, max_steps: int = 10000) -> ExecutionMetrics:
        """Execute all operations"""
        start_time = time.time()
        steps = 0
        
        while steps < max_steps and self.step():
            steps += 1
        
        return ExecutionMetrics(
            steps=steps,
            time_elapsed=time.time() - start_time,
            memory_accesses=len(self.trace),
            state_transitions=len(self.operations),
            halted=self.halted,
            output=self.output,
            trace=self.trace
        )
    
    def get_state(self) -> Dict[str, Any]:
        amplitudes = np.abs(self.modes)
        phases = np.angle(self.modes)
        return {
            'modes': self.modes.tolist(),
            'amplitudes': amplitudes.tolist(),
            'phases': phases.tolist(),
            'total_energy': float(np.sum(amplitudes**2)),
            'output': self.output
        }


# Registry of available models
MODELS = {
    'turing': TuringMachine,
    'geometric': GeometricComputationModel,
    'resonance': ResonanceComputationModel
}


def create_model(model_type: str, **kwargs) -> ComputationModel:
    """Factory function to create model instances"""
    if model_type not in MODELS:
        raise ValueError(f"Unknown model: {model_type}. Available: {list(MODELS.keys())}")
    return MODELS[model_type](**kwargs)


if __name__ == "__main__":
    print("Simulation Framework Initialized")
    print(f"Available models: {', '.join(MODELS.keys())}")
