"""
Benchmarking and comparison suite for computational models
Measure performance, accuracy, and emergent properties
"""

import json
from typing import Dict, List, Tuple, Any
import numpy as np
from simulation_framework import create_model, ExecutionMetrics
from example_programs import TURING_INCREMENT, GEOMETRIC_FIBONACCI, RESONANCE_OPTIMIZE
import matplotlib.pyplot as plt
from dataclasses import asdict


class ModelComparison:
    """Compare multiple models on the same problem class"""
    
    def __init__(self):
        self.results = {}
        self.models_tested = []
        
    def run_test(self, model_name: str, model_type: str, program: str, 
                 input_data: Any, test_name: str) -> ExecutionMetrics:
        """Run a single test on a model"""
        print(f"  Testing {model_name} on {test_name}...")
        
        model = create_model(model_type)
        model.initialize(program, input_data)
        metrics = model.run(max_steps=1000)
        
        if model_name not in self.results:
            self.results[model_name] = []
        
        self.results[model_name].append({
            'test': test_name,
            'model_type': model_type,
            'metrics': metrics,
            'state': model.get_state()
        })
        
        if model_name not in self.models_tested:
            self.models_tested.append(model_name)
        
        return metrics
    
    def summarize(self) -> Dict[str, Any]:
        """Generate summary statistics"""
        summary = {}
        
        for model_name, tests in self.results.items():
            total_steps = sum(t['metrics'].steps for t in tests)
            total_time = sum(t['metrics'].time_elapsed for t in tests)
            avg_memory_ops = np.mean([t['metrics'].memory_accesses for t in tests])
            
            summary[model_name] = {
                'tests_run': len(tests),
                'total_steps': total_steps,
                'avg_steps_per_test': total_steps / len(tests) if tests else 0,
                'total_time_ms': total_time * 1000,
                'avg_time_ms': (total_time / len(tests) * 1000) if tests else 0,
                'avg_memory_accesses': avg_memory_ops,
                'success_rate': sum(1 for t in tests if t['metrics'].halted) / len(tests) if tests else 0,
            }
        
        return summary
    
    def compare_efficiency(self) -> Dict[str, float]:
        """Compute efficiency scores (lower steps = better)"""
        summary = self.summarize()
        scores = {}
        
        min_steps = min(s['avg_steps_per_test'] for s in summary.values())
        
        for model_name, stats in summary.items():
            efficiency = min_steps / (stats['avg_steps_per_test'] or 1)
            scores[model_name] = efficiency
        
        return scores
    
    def report(self, verbose: bool = True) -> str:
        """Generate formatted report"""
        summary = self.summarize()
        scores = self.compare_efficiency()
        
        report = "=" * 70 + "\n"
        report += "COMPUTATIONAL MODEL COMPARISON REPORT\n"
        report += "=" * 70 + "\n\n"
        
        for model_name, stats in summary.items():
            report += f"Model: {model_name}\n"
            report += f"  Tests Run: {stats['tests_run']}\n"
            report += f"  Avg Steps/Test: {stats['avg_steps_per_test']:.1f}\n"
            report += f"  Avg Time (ms): {stats['avg_time_ms']:.3f}\n"
            report += f"  Avg Memory Ops: {stats['avg_memory_accesses']:.1f}\n"
            report += f"  Success Rate: {stats['success_rate']:.1%}\n"
            report += f"  Efficiency Score: {scores[model_name]:.2f}x\n"
            report += "\n"
        
        report += "=" * 70 + "\n"
        report += "KEY FINDINGS:\n"
        report += "=" * 70 + "\n"
        
        best_steps = min(scores.values())
        best_model = [k for k, v in scores.items() if v == best_steps][0]
        
        report += f"✓ Fastest (lowest steps): {best_model}\n"
        
        best_time = min((s['avg_time_ms'] for s in summary.values()), default=0)
        best_time_model = [k for k, v in summary.items() if v['avg_time_ms'] == best_time][0]
        report += f"✓ Fastest (execution time): {best_time_model}\n"
        
        return report
    
    def export_json(self, filepath: str):
        """Export results as JSON"""
        export_data = {
            'summary': self.summarize(),
            'efficiency_scores': self.compare_efficiency(),
            'models_tested': self.models_tested,
            'detailed_results': {}
        }
        
        for model_name, tests in self.results.items():
            export_data['detailed_results'][model_name] = []
            for test in tests:
                test_data = {
                    'test_name': test['test'],
                    'model_type': test['model_type'],
                    'metrics': {
                        'steps': test['metrics'].steps,
                        'time_elapsed': test['metrics'].time_elapsed,
                        'memory_accesses': test['metrics'].memory_accesses,
                        'state_transitions': test['metrics'].state_transitions,
                        'halted': test['metrics'].halted,
                    },
                    'final_state': test['state']
                }
                export_data['detailed_results'][model_name].append(test_data)
        
        with open(filepath, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
        
        print(f"Results exported to {filepath}")


class AnalysisTools:
    """Tools for analyzing computational behavior"""
    
    @staticmethod
    def trace_path_analysis(trace: List[Dict[str, Any]], model_type: str) -> Dict[str, Any]:
        """Analyze the execution trace"""
        analysis = {
            'trace_length': len(trace),
            'unique_states': len(set(str(t) for t in trace)),
            'loops_detected': 0,
            'max_depth': 0,
            'branching_factor': 0,
        }
        
        if model_type == 'turing':
            # Find potential loops in state transitions
            states_seen = {}
            for i, step in enumerate(trace):
                state_key = step.get('state', 'unknown')
                if state_key in states_seen:
                    analysis['loops_detected'] += 1
                states_seen[state_key] = i
        
        return analysis
    
    @staticmethod
    def convergence_analysis(trace: List[Dict[str, Any]], model_type: str) -> Dict[str, Any]:
        """Analyze if execution converges to a solution"""
        
        if model_type == 'geometric':
            magnitudes = [t.get('magnitude', 0) for t in trace]
            if len(magnitudes) > 1:
                convergence_rate = abs(magnitudes[-1] - magnitudes[-2])
                return {
                    'type': 'magnitude_convergence',
                    'final_magnitude': magnitudes[-1],
                    'initial_magnitude': magnitudes[0],
                    'convergence_rate': convergence_rate,
                    'converged': convergence_rate < 1e-6
                }
        
        elif model_type == 'resonance':
            energies = [t.get('total_energy', 0) for t in trace]
            if len(energies) > 1:
                energy_changes = [abs(energies[i] - energies[i-1]) for i in range(1, len(energies))]
                return {
                    'type': 'energy_stabilization',
                    'final_energy': energies[-1],
                    'initial_energy': energies[0],
                    'avg_energy_change': np.mean(energy_changes),
                    'stable': np.mean(energy_changes) < 1e-6
                }
        
        return {'type': 'unknown', 'analyzed': False}
    
    @staticmethod
    def complexity_profile(metrics: ExecutionMetrics) -> Dict[str, Any]:
        """Estimate computational complexity profile"""
        
        return {
            'steps_taken': metrics.steps,
            'state_space_explored': metrics.state_transitions,
            'memory_efficiency': metrics.memory_accesses / (metrics.steps + 1),
            'estimated_complexity': 'O(n)' if metrics.steps < 100 else 
                                   'O(n²)' if metrics.steps < 10000 else 'O(n³+)',
        }


def run_comparison_suite():
    """Run comprehensive comparison of models"""
    
    print("\n" + "=" * 70)
    print("COMPUTATIONAL MODELS COMPARISON SUITE")
    print("=" * 70 + "\n")
    
    comparison = ModelComparison()
    analyzer = AnalysisTools()
    
    # Test 1: Turing Machine - Binary Increment
    print("TEST 1: Binary Increment (Turing Machine)")
    metrics_tm = comparison.run_test(
        'Turing Machine',
        'turing',
        TURING_INCREMENT,
        '101',
        'binary_increment'
    )
    print(f"    Result: {metrics_tm.output} (Steps: {metrics_tm.steps})")
    
    # Test 2: Geometric Model - Fibonacci
    print("\nTEST 2: Fibonacci-like Computation (Geometric Model)")
    metrics_geo = comparison.run_test(
        'Geometric Model',
        'geometric',
        GEOMETRIC_FIBONACCI,
        [1, 0, 0, 0, 0, 0],
        'fibonacci_rotation'
    )
    print(f"    State: {metrics_geo.output} (Steps: {metrics_geo.steps})")
    
    # Test 3: Resonance Model - Optimization
    print("\nTEST 3: Optimization via Resonance (Resonance Model)")
    metrics_res = comparison.run_test(
        'Resonance Model',
        'resonance',
        RESONANCE_OPTIMIZE,
        1.0,
        'harmonic_optimization'
    )
    print(f"    Output: {metrics_res.output} (Steps: {metrics_res.steps})")
    
    # Run multiple inputs to build statistical profile
    print("\n" + "-" * 70)
    print("STATISTICAL PROFILING (Multiple inputs)...")
    print("-" * 70)
    
    inputs = ['10', '100', '1010', '11111']
    for inp in inputs:
        print(f"\nTesting with input: {inp}")
        comparison.run_test('Turing Machine', 'turing', TURING_INCREMENT, inp, f'increment_{inp}')
    
    # Generate report
    print("\n" + "=" * 70)
    report = comparison.report(verbose=True)
    print(report)
    
    # Export results
    comparison.export_json('/workspace/comparison_results.json')
    
    # Analysis
    print("\nDETAILED ANALYSIS:")
    print("-" * 70)
    
    if metrics_tm.trace:
        trace_analysis = analyzer.trace_path_analysis(metrics_tm.trace, 'turing')
        print(f"\nTuring Machine Trace Analysis:")
        print(f"  Trace length: {trace_analysis['trace_length']}")
        print(f"  Unique states: {trace_analysis['unique_states']}")
        print(f"  Loops detected: {trace_analysis['loops_detected']}")
    
    if metrics_geo.trace:
        conv_analysis = analyzer.convergence_analysis(metrics_geo.trace, 'geometric')
        print(f"\nGeometric Model Convergence:")
        for key, val in conv_analysis.items():
            if key != 'type':
                print(f"  {key}: {val}")
    
    if metrics_res.trace:
        res_analysis = analyzer.convergence_analysis(metrics_res.trace, 'resonance')
        print(f"\nResonance Model Energy Profile:")
        for key, val in res_analysis.items():
            if key != 'type':
                print(f"  {key}: {val}")
    
    print("\n" + "=" * 70 + "\n")
    
    return comparison, analyzer


if __name__ == "__main__":
    comparison, analyzer = run_comparison_suite()
