# Senemosìa Punto Zero v2.0 - Benchmark Dataset

**Author:** Fabian Leo Naressi, Independent Researcher

**DOI:** [To be assigned upon publication]

**License:** MIT License

**Date:** July 2026

---

## Overview

This dataset contains comprehensive benchmark results from the Senemosìa Punto Zero v2.0 heterogeneous computing framework. The framework unifies six distinct computational paradigms for comparison and analysis.

## Dataset Contents

### 1. benchmark_results.csv
Complete benchmark results across 3 test tasks for all 6 paradigms:
- **Binary Increment (8-bit)**: Basic arithmetic test
- **Search (256 items)**: Database lookup showing quantum advantage
- **Pattern Recognition**: Classification task for neuromorphic evaluation

Metrics: energy (pJ/op), latency (μs), parallelism (0-1), steps, accuracy, complexity class

### 2. energy_measurements.csv
Detailed energy measurements for each paradigm:
- Neuromorphic: 10-25 pJ/op (ultra-efficient spike-based)
- Turing: 60 pJ/op (baseline)
- Analog: 150 pJ/op (continuous-time)
- Geometric: 350 pJ/op (6D transformations)
- Resonance: 450 pJ/op (wave interference)
- Quantum: 600 pJ/op (with setup overhead)

### 3. latency_data.csv
Latency measurements across different input sizes (8-256 bits):
- p50, p95, p99 percentile latencies
- Throughput in operations/second

### 4. parallelism_scores.csv
Parallelism characteristics of each paradigm:
- Vectorization potential
- Execution width
- Dependency depth
- Synchronization overhead

## The Six Paradigms

| Paradigm | Key Feature | Best Use Case |
|----------|-------------|---------------|
| Turing | Sequential | Deterministic logic |
| Geometric | 6D Golden Ratio | High-dimensional tensors |
| Resonance | 8 Harmonic Modes | Signal processing |
| Quantum | Grover Search | O(√N) search |
| Neuromorphic | STDP Learning | Pattern recognition |
| Analog | Kirchhoff Laws | ODE solving |

## Substrate-Problem Alignment Principle

**Efficiency = 1 / |Problem ⊗ Substrate Mismatch|**

The optimal paradigm depends on problem structure:
- Sequential logic → Turing
- Unstructured search → Quantum (Grover)
- Pattern recognition → Neuromorphic
- Differential equations → Analog

## Citation

If you use this dataset, please cite:

```bibtex
@misc{senemosia2026,
  title={Senemosìa Punto Zero v2.0 Benchmark Dataset},
  author={Fabian Leo Naressi},
  year={2026},
  publisher={Figshare},
  doi={10.xxxxx/xxxxx},
  url={https://figshare.com/collections/xxxxx}
}
```

## Related Publications

- "Orchestrating Heterogeneous Computing Substrates: A Unified 6-Paradigm Co-Design Framework and Benchmarking Suite" - IEEE Micro (Submitted July 2026)

## Contact

Fabian Leo Naressi
Independent Researcher
fabian.naressi@example.com

## License

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy of this dataset and associated documentation files, to deal in the Dataset without restriction.
