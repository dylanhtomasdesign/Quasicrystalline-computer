"""
Example programs for different computational models
Demonstrates how to express algorithms in each paradigm
"""

# ============================================================================
# TURING MACHINE PROGRAMS
# ============================================================================

# Program 1: Binary Increment (add 1 to binary number)
TURING_INCREMENT = """
# Increment a binary number by 1
# Input: binary string (e.g., "101")
# Output: incremented binary string

START: find_right
HALT: done

find_right,0 -> 0,R,find_right
find_right,1 -> 1,R,find_right
find_right,_ -> _,L,add_one

add_one,0 -> 1,L,done
add_one,1 -> 0,L,add_one
add_one,_ -> 1,L,done
"""

# Program 2: Palindrome checker
TURING_PALINDROME = """
# Check if input is a palindrome
# Marks matching pairs from outside-in

START: mark_left
HALT: check_result

mark_left,a -> X,R,scan_right_a
mark_left,b -> X,R,scan_right_b
mark_left,X -> X,R,mark_left
mark_left,_ -> _,L,result_accept

scan_right_a,X -> X,R,scan_right_a
scan_right_a,a -> a,R,scan_right_a
scan_right_a,b -> b,R,scan_right_a
scan_right_a,_ -> _,L,check_left_a

check_left_a,a -> X,L,back_to_start
check_left_a,X -> X,L,check_left_a
check_left_a,b -> _,L,result_reject
check_left_a,_ -> _,L,result_reject

back_to_start,a -> a,L,back_to_start
back_to_start,b -> b,L,back_to_start
back_to_start,X -> X,L,back_to_start
back_to_start,_ -> _,R,mark_left

scan_right_b,X -> X,R,scan_right_b
scan_right_b,a -> a,R,scan_right_b
scan_right_b,b -> b,R,scan_right_b
scan_right_b,_ -> _,L,check_left_b

check_left_b,b -> X,L,back_to_start
check_left_b,X -> X,L,check_left_b
check_left_b,a -> _,L,result_reject
check_left_b,_ -> _,L,result_reject

result_accept,_ -> 1,L,check_result
result_reject,_ -> 0,L,check_result
"""

# Program 3: Simple counter (count input length)
TURING_COUNTER = """
# Count the length of input string

START: count_loop
HALT: done

count_loop,0 -> 1,R,count_loop
count_loop,1 -> 1,R,count_loop
count_loop,a -> 1,R,count_loop
count_loop,b -> 1,R,count_loop
count_loop,_ -> _,L,done
"""


# ============================================================================
# GEOMETRIC COMPUTATION PROGRAMS
# ============================================================================

# Program 1: Fibonacci via rotation sequences
GEOMETRIC_FIBONACCI = """
# Compute Fibonacci number via golden ratio rotations
# Rotation in the phi-plane converges to Fibonacci ratios

# Initialize state to (1, 0, 0, 0, 0, 0)
# Rotate by golden ratio angle repeatedly

# Golden ratio angle: arctan(phi) ≈ 1.0172 radians
# After N rotations, x-component encodes F(N)

ROTATE: 0,1,1.0172
ROTATE: 0,1,1.0172
ROTATE: 0,1,1.0172
ROTATE: 0,1,1.0172
ROTATE: 0,1,1.0172
NORMALIZE
THRESHOLD: 0,0.5 -> output
"""

# Program 2: Sorting via geometric projection
GEOMETRIC_SORT = """
# Sort array by projecting onto sorted direction
# Project data onto principal component (1D line)
# Read-off in order = sorted sequence

# Initial: load data into state dimensions
# Project onto axis where sorted order is largest variation

PROJECT: 2
PROJECT: 3
PROJECT: 4
PROJECT: 5
SCALE: 10
THRESHOLD: 0,5 -> output
THRESHOLD: 1,5 -> output
"""

# Program 3: Path finding via geometric convergence
GEOMETRIC_PATHFIND = """
# Find shortest path by rotating toward target direction
# State vector converges to target in high-dimensional space
# Rotations alternate between dimensions to spiral inward

ROTATE: 0,1,0.785
ROTATE: 1,2,0.785
ROTATE: 2,3,0.785
ROTATE: 3,4,0.785
ROTATE: 4,5,0.785
SCALE: 0.99
ROTATE: 0,1,0.785
ROTATE: 1,2,0.785
ROTATE: 2,3,0.785
ROTATE: 3,4,0.785
ROTATE: 4,5,0.785
SCALE: 0.99
THRESHOLD: 0,0.8 -> output
"""


# ============================================================================
# RESONANCE COMPUTATION PROGRAMS
# ============================================================================

# Program 1: Constructive interference for pattern matching
RESONANCE_PATTERN_MATCH = """
# Match pattern via resonance
# Excite modes corresponding to pattern
# Measure interference: high = match, low = no match

EXCITE: 0,1.0,0.0
EXCITE: 1,1.0,0.0
EXCITE: 2,1.0,0.0
INTERFERE: 0,1
INTERFERE: 1,2
INTERFERE: 0,2
NORMALIZE
MEASURE: 0,0.7 -> output
"""

# Program 2: Search via harmonic resonance
RESONANCE_SEARCH = """
# Search algorithm via mode coupling
# Couple modes to propagate information
# Target mode amplifies when solution is near

EXCITE: 0,1.0,0.0
EXCITE: 1,0.5,1.57
EXCITE: 2,0.3,3.14
COUPLE: 0,1,0.2
COUPLE: 1,2,0.2
COUPLE: 0,2,0.1
COUPLE: 0,1,0.2
COUPLE: 1,2,0.2
NORMALIZE
MEASURE: 0,0.6 -> output
MEASURE: 1,0.4 -> output
"""

# Program 3: Optimization via harmonic damping
RESONANCE_OPTIMIZE = """
# Optimization by exciting modes toward solution
# Damping unwanted modes, amplifying promising directions

EXCITE: 0,2.0,0.0
EXCITE: 1,1.5,0.785
EXCITE: 2,1.0,1.57
EXCITE: 3,0.5,2.356
INTERFERE: 0,1
INTERFERE: 1,2
INTERFERE: 2,3
COUPLE: 0,1,0.15
COUPLE: 1,2,0.15
COUPLE: 2,3,0.15
NORMALIZE
MEASURE: 0,0.8 -> output
"""


# ============================================================================
# PROBLEM DEFINITIONS (same for all models)
# ============================================================================

PROBLEMS = {
    'increment': {
        'description': 'Increment binary number by 1',
        'inputs': ['101', '111', '1000', '1010101'],
        'turing': (TURING_INCREMENT, 'increment'),
        'geometric': (GEOMETRIC_FIBONACCI, [1, 0, 0, 0, 0, 0]),
        'resonance': (RESONANCE_PATTERN_MATCH, 1.0),
    },
    'palindrome': {
        'description': 'Check if string is palindrome',
        'inputs': ['aba', 'abba', 'abc', 'racecar'],
        'turing': (TURING_PALINDROME, 'check'),
    },
    'fibonacci': {
        'description': 'Compute Fibonacci via model-specific method',
        'inputs': [1, 2, 3, 4, 5],
        'geometric': (GEOMETRIC_FIBONACCI, [1, 0, 0, 0, 0, 0]),
        'resonance': (RESONANCE_OPTIMIZE, 1.0),
    },
}


if __name__ == "__main__":
    print("Example Programs Available:")
    print(f"  Turing: increment, palindrome, counter")
    print(f"  Geometric: fibonacci, sort, pathfind")
    print(f"  Resonance: pattern_match, search, optimize")
