"""
EXTENDED FRAMEWORK: 11 Discipline Integration
Incorporates Software Engineering, AI/ML, Networking, Databases, 
Parallel/Distributed Computing, HCI, Graphics, OS, and Symbolic/Numeric Computing
into the computational models simulator.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Optional, Callable
import numpy as np
from enum import Enum
import heapq
from collections import defaultdict, deque
import threading
import time


# ============================================================================
# 1. SOFTWARE ENGINEERING MODULE
# ============================================================================

class DesignPattern(Enum):
    """Software design patterns applicable to models"""
    SINGLETON = "singleton"
    FACTORY = "factory"
    OBSERVER = "observer"
    STRATEGY = "strategy"
    DECORATOR = "decorator"
    ADAPTER = "adapter"


@dataclass
class Architecture:
    """Software architecture specification"""
    name: str
    components: List[str]  # Component names
    dependencies: Dict[str, List[str]]  # Component dependencies
    interfaces: Dict[str, List[str]]  # Component interfaces
    
    def validate_architecture(self) -> bool:
        """Check for circular dependencies"""
        visited = set()
        rec_stack = set()
        
        def has_cycle(component):
            visited.add(component)
            rec_stack.add(component)
            
            for dep in self.dependencies.get(component, []):
                if dep not in visited:
                    if has_cycle(dep):
                        return True
                elif dep in rec_stack:
                    return True
            
            rec_stack.remove(component)
            return False
        
        for comp in self.components:
            if comp not in visited:
                if has_cycle(comp):
                    return False
        return True


class TestStrategy(ABC):
    """Software testing strategies"""
    
    @abstractmethod
    def test(self, component: Any) -> Dict[str, bool]:
        pass


class UnitTest(TestStrategy):
    """Unit testing"""
    def test(self, component: Any) -> Dict[str, bool]:
        return {"unit_test": hasattr(component, "__call__")}


class IntegrationTest(TestStrategy):
    """Integration testing between components"""
    def test(self, components: List[Any]) -> Dict[str, bool]:
        return {"integration": len(components) > 1}


# ============================================================================
# 2. ARTIFICIAL INTELLIGENCE & MACHINE LEARNING MODULE
# ============================================================================

class NeuralNetwork:
    """Simple feedforward neural network"""
    
    def __init__(self, layer_sizes: List[int]):
        self.layers = layer_sizes
        self.weights = [np.random.randn(layer_sizes[i], layer_sizes[i+1]) 
                       for i in range(len(layer_sizes)-1)]
        self.biases = [np.random.randn(1, layer_sizes[i+1]) 
                      for i in range(len(layer_sizes)-1)]
    
    def forward(self, x: np.ndarray) -> np.ndarray:
        """Forward propagation"""
        activation = x
        for w, b in zip(self.weights, self.biases):
            activation = np.tanh(np.dot(activation, w) + b)
        return activation
    
    def backward(self, x: np.ndarray, y: np.ndarray, learning_rate: float = 0.01):
        """Simplified backpropagation"""
        output = self.forward(x)
        error = y - output
        
        # Update last layer weights
        self.weights[-1] += learning_rate * np.dot(x.T, error)
        self.biases[-1] += learning_rate * np.sum(error, axis=0, keepdims=True)


class ReinforcementLearningAgent:
    """Q-learning agent"""
    
    def __init__(self, state_space_size: int, action_space_size: int, alpha: float = 0.1, gamma: float = 0.99):
        self.q_table = np.zeros((state_space_size, action_space_size))
        self.alpha = alpha  # Learning rate
        self.gamma = gamma  # Discount factor
    
    def choose_action(self, state: int, epsilon: float = 0.1) -> int:
        """Epsilon-greedy action selection"""
        if np.random.random() < epsilon:
            return np.random.randint(self.q_table.shape[1])
        return np.argmax(self.q_table[state])
    
    def update(self, state: int, action: int, reward: float, next_state: int):
        """Q-learning update"""
        current_q = self.q_table[state, action]
        max_next_q = np.max(self.q_table[next_state])
        new_q = current_q + self.alpha * (reward + self.gamma * max_next_q - current_q)
        self.q_table[state, action] = new_q


class SearchAlgorithm(ABC):
    """AI search algorithms"""
    
    @abstractmethod
    def search(self, initial_state: Any, goal_state: Any) -> List[Any]:
        pass


class BreadthFirstSearch(SearchAlgorithm):
    """BFS algorithm"""
    
    def search(self, initial_state: Any, goal_state: Any, neighbors_fn: Callable) -> List[Any]:
        queue = deque([(initial_state, [initial_state])])
        visited = {initial_state}
        
        while queue:
            state, path = queue.popleft()
            
            if state == goal_state:
                return path
            
            for neighbor in neighbors_fn(state):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        
        return []


class AStarSearch(SearchAlgorithm):
    """A* algorithm"""
    
    def search(self, initial_state: Any, goal_state: Any, 
              neighbors_fn: Callable, heuristic_fn: Callable) -> List[Any]:
        open_set = [(heuristic_fn(initial_state), 0, initial_state, [initial_state])]
        visited = set()
        
        while open_set:
            _, g_score, state, path = heapq.heappop(open_set)
            
            if state in visited:
                continue
            
            visited.add(state)
            
            if state == goal_state:
                return path
            
            for neighbor in neighbors_fn(state):
                if neighbor not in visited:
                    h_score = heuristic_fn(neighbor)
                    f_score = g_score + 1 + h_score
                    heapq.heappush(open_set, (f_score, g_score + 1, neighbor, path + [neighbor]))
        
        return []


# ============================================================================
# 3. NETWORKING MODULE
# ============================================================================

@dataclass
class NetworkPacket:
    """Network packet structure"""
    source: str
    destination: str
    data: bytes
    timestamp: float
    protocol: str  # TCP, UDP, etc.
    sequence_number: int = 0


class NetworkProtocol(ABC):
    """Base network protocol"""
    
    @abstractmethod
    def send(self, packet: NetworkPacket) -> bool:
        pass
    
    @abstractmethod
    def receive(self) -> Optional[NetworkPacket]:
        pass


class TCPProtocol(NetworkProtocol):
    """TCP protocol simulation"""
    
    def __init__(self):
        self.connections = {}  # Connection state tracking
        self.buffer = deque()
        self.sequence_num = 0
    
    def send(self, packet: NetworkPacket) -> bool:
        """TCP three-way handshake simulation"""
        conn_key = (packet.source, packet.destination)
        
        if conn_key not in self.connections:
            self.connections[conn_key] = "SYN_SENT"
            return False
        
        if self.connections[conn_key] == "ESTABLISHED":
            packet.sequence_number = self.sequence_num
            self.sequence_num += 1
            self.buffer.append(packet)
            return True
        
        return False
    
    def receive(self) -> Optional[NetworkPacket]:
        return self.buffer.popleft() if self.buffer else None


class UDPProtocol(NetworkProtocol):
    """UDP protocol simulation (connectionless)"""
    
    def __init__(self):
        self.buffer = deque()
    
    def send(self, packet: NetworkPacket) -> bool:
        self.buffer.append(packet)
        return True
    
    def receive(self) -> Optional[NetworkPacket]:
        return self.buffer.popleft() if self.buffer else None


class RoutingAlgorithm(ABC):
    """Network routing"""
    
    @abstractmethod
    def route(self, source: str, destination: str, network_graph: Dict) -> List[str]:
        pass


class DijkstraRouting(RoutingAlgorithm):
    """Dijkstra's routing algorithm"""
    
    def route(self, source: str, destination: str, network_graph: Dict[str, Dict[str, float]]) -> List[str]:
        distances = {node: float('inf') for node in network_graph}
        distances[source] = 0
        previous = {node: None for node in network_graph}
        unvisited = set(network_graph.keys())
        
        while unvisited:
            current = min(unvisited, key=lambda node: distances[node])
            
            if distances[current] == float('inf'):
                break
            
            if current == destination:
                path = []
                node = destination
                while node:
                    path.append(node)
                    node = previous[node]
                return path[::-1]
            
            for neighbor, weight in network_graph[current].items():
                if neighbor in unvisited:
                    new_distance = distances[current] + weight
                    if new_distance < distances[neighbor]:
                        distances[neighbor] = new_distance
                        previous[neighbor] = current
            
            unvisited.remove(current)
        
        return []


# ============================================================================
# 4. DATABASE MODULE
# ============================================================================

@dataclass
class DatabaseRecord:
    """Database record"""
    id: int
    data: Dict[str, Any]
    timestamp: float


class Index(ABC):
    """Database indexing strategy"""
    
    @abstractmethod
    def insert(self, key: Any, record_id: int):
        pass
    
    @abstractmethod
    def search(self, key: Any) -> List[int]:
        pass


class BTreeIndex(Index):
    """B-tree index implementation"""
    
    def __init__(self, order: int = 3):
        self.order = order
        self.index = {}  # Simplified: dict-based
    
    def insert(self, key: Any, record_id: int):
        if key not in self.index:
            self.index[key] = []
        self.index[key].append(record_id)
    
    def search(self, key: Any) -> List[int]:
        return self.index.get(key, [])


class HashIndex(Index):
    """Hash-based indexing"""
    
    def __init__(self, size: int = 1000):
        self.table = [[] for _ in range(size)]
        self.size = size
    
    def _hash(self, key: Any) -> int:
        return hash(key) % self.size
    
    def insert(self, key: Any, record_id: int):
        idx = self._hash(key)
        self.table[idx].append((key, record_id))
    
    def search(self, key: Any) -> List[int]:
        idx = self._hash(key)
        return [rid for k, rid in self.table[idx] if k == key]


class TransactionManager:
    """ACID transaction support"""
    
    def __init__(self):
        self.active_transactions = {}
        self.committed_data = {}
        self.locks = defaultdict(threading.Lock)
    
    def begin_transaction(self, tx_id: int):
        self.active_transactions[tx_id] = {}
    
    def read(self, tx_id: int, key: str) -> Any:
        with self.locks[key]:
            return self.committed_data.get(key)
    
    def write(self, tx_id: int, key: str, value: Any):
        self.active_transactions[tx_id][key] = value
    
    def commit(self, tx_id: int) -> bool:
        """Commit transaction (atomicity)"""
        if tx_id not in self.active_transactions:
            return False
        
        # Acquire all locks
        for key in self.active_transactions[tx_id]:
            with self.locks[key]:
                self.committed_data[key] = self.active_transactions[tx_id][key]
        
        del self.active_transactions[tx_id]
        return True


# ============================================================================
# 5. PARALLEL & DISTRIBUTED COMPUTING MODULE
# ============================================================================

class ThreadPool:
    """Simple thread pool executor"""
    
    def __init__(self, num_threads: int = 4):
        self.num_threads = num_threads
        self.task_queue = deque()
        self.workers = []
        self.lock = threading.Lock()
        self.event = threading.Event()
    
    def submit(self, task: Callable):
        with self.lock:
            self.task_queue.append(task)
    
    def execute(self):
        """Execute all tasks (blocking)"""
        threads = []
        for _ in range(self.num_threads):
            t = threading.Thread(target=self._worker)
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join()
    
    def _worker(self):
        while True:
            with self.lock:
                if not self.task_queue:
                    break
                task = self.task_queue.popleft()
            task()


class MapReduce:
    """MapReduce framework"""
    
    def __init__(self, data: List[Any]):
        self.data = data
        self.results = {}
    
    def map(self, map_fn: Callable) -> Dict[Any, List[Any]]:
        """Map phase"""
        mapped = defaultdict(list)
        for item in self.data:
            key, value = map_fn(item)
            mapped[key].append(value)
        return dict(mapped)
    
    def reduce(self, reduce_fn: Callable, mapped_data: Dict) -> Dict[Any, Any]:
        """Reduce phase"""
        self.results = {}
        for key, values in mapped_data.items():
            self.results[key] = reduce_fn(values)
        return self.results


class ConsensusAlgorithm(ABC):
    """Distributed consensus"""
    
    @abstractmethod
    def reach_consensus(self, nodes: List[str], values: Dict[str, Any]) -> Any:
        pass


class RaftConsensus(ConsensusAlgorithm):
    """Simplified Raft consensus"""
    
    def __init__(self):
        self.term = 0
        self.leader = None
        self.committed_index = 0
    
    def reach_consensus(self, nodes: List[str], values: Dict[str, Any]) -> Any:
        """Simplified: majority wins"""
        vote_counts = defaultdict(int)
        
        for node in nodes:
            if node in values:
                vote_counts[values[node]] += 1
        
        # Majority consensus
        majority = len(nodes) // 2 + 1
        for value, count in vote_counts.items():
            if count >= majority:
                self.committed_index += 1
                return value
        
        return None


# ============================================================================
# 6. HUMAN-COMPUTER INTERACTION (HCI) MODULE
# ============================================================================

class UserInteractionModel:
    """Models user interaction patterns"""
    
    def __init__(self):
        self.interaction_history = []
        self.user_preferences = {}
    
    def record_interaction(self, action: str, target: str, timestamp: float):
        self.interaction_history.append({
            'action': action,
            'target': target,
            'timestamp': timestamp
        })
    
    def predict_next_action(self) -> str:
        """Simple prediction based on patterns"""
        if len(self.interaction_history) < 2:
            return "unknown"
        
        # Return most common recent action
        recent = self.interaction_history[-5:]
        actions = [i['action'] for i in recent]
        return max(set(actions), key=actions.count) if actions else "unknown"


class InterfaceDesign:
    """Interface design principles"""
    
    @staticmethod
    def heuristic_evaluation(interface_elements: List[str]) -> Dict[str, float]:
        """Nielsen's 10 usability heuristics"""
        heuristics = {
            'visibility': 0.8 if len(interface_elements) > 0 else 0.0,
            'match_system_world': 0.7,
            'user_control': 0.85,
            'error_prevention': 0.75,
            'help_documentation': 0.6 if len(interface_elements) > 3 else 0.3
        }
        return heuristics
    
    @staticmethod
    def accessibility_score(interface: Dict) -> float:
        """Calculate accessibility score (WCAG guidelines)"""
        score = 0.0
        if interface.get('keyboard_accessible'):
            score += 0.25
        if interface.get('screen_reader_compatible'):
            score += 0.25
        if interface.get('color_contrast') > 4.5:  # WCAG AA standard
            score += 0.25
        if interface.get('font_readable'):
            score += 0.25
        return score


# ============================================================================
# 7. COMPUTER GRAPHICS MODULE
# ============================================================================

@dataclass
class Point3D:
    x: float
    y: float
    z: float
    
    def to_array(self) -> np.ndarray:
        return np.array([self.x, self.y, self.z])


class TransformationMatrix:
    """3D graphics transformations"""
    
    @staticmethod
    def translation_matrix(tx: float, ty: float, tz: float) -> np.ndarray:
        return np.array([
            [1, 0, 0, tx],
            [0, 1, 0, ty],
            [0, 0, 1, tz],
            [0, 0, 0, 1]
        ])
    
    @staticmethod
    def rotation_matrix_z(angle: float) -> np.ndarray:
        c, s = np.cos(angle), np.sin(angle)
        return np.array([
            [c, -s, 0, 0],
            [s, c, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])
    
    @staticmethod
    def scale_matrix(sx: float, sy: float, sz: float) -> np.ndarray:
        return np.array([
            [sx, 0, 0, 0],
            [0, sy, 0, 0],
            [0, 0, sz, 0],
            [0, 0, 0, 1]
        ])
    
    @staticmethod
    def compose_transforms(matrices: List[np.ndarray]) -> np.ndarray:
        result = np.eye(4)
        for matrix in matrices:
            result = result @ matrix
        return result


class RenderingPipeline:
    """Graphics rendering pipeline"""
    
    def __init__(self):
        self.vertices = []
        self.triangles = []
    
    def add_vertex(self, point: Point3D):
        self.vertices.append(point)
    
    def add_triangle(self, v1_idx: int, v2_idx: int, v3_idx: int):
        self.triangles.append((v1_idx, v2_idx, v3_idx))
    
    def compute_normals(self) -> Dict[int, np.ndarray]:
        """Compute vertex normals for lighting"""
        normals = defaultdict(lambda: np.array([0.0, 0.0, 0.0]))
        
        for v1_idx, v2_idx, v3_idx in self.triangles:
            v1 = self.vertices[v1_idx].to_array()
            v2 = self.vertices[v2_idx].to_array()
            v3 = self.vertices[v3_idx].to_array()
            
            # Compute face normal
            edge1 = v2 - v1
            edge2 = v3 - v1
            face_normal = np.cross(edge1, edge2)
            
            # Accumulate to vertex normals
            for idx in [v1_idx, v2_idx, v3_idx]:
                normals[idx] += face_normal
        
        # Normalize
        for idx in normals:
            norm = np.linalg.norm(normals[idx])
            if norm > 0:
                normals[idx] /= norm
        
        return dict(normals)


# ============================================================================
# 8. OPERATING SYSTEMS MODULE
# ============================================================================

class ProcessState(Enum):
    NEW = "new"
    READY = "ready"
    RUNNING = "running"
    WAITING = "waiting"
    TERMINATED = "terminated"


@dataclass
class Process:
    pid: int
    name: str
    priority: int = 0
    state: ProcessState = ProcessState.NEW
    memory_allocated: int = 0


class Scheduler(ABC):
    """CPU scheduling algorithm"""
    
    @abstractmethod
    def schedule(self, processes: List[Process]) -> List[Process]:
        pass


class RoundRobinScheduler(Scheduler):
    """Round Robin scheduling"""
    
    def __init__(self, time_quantum: int = 10):
        self.time_quantum = time_quantum
    
    def schedule(self, processes: List[Process]) -> List[Process]:
        ready_queue = deque(processes)
        execution_order = []
        
        while ready_queue:
            process = ready_queue.popleft()
            process.state = ProcessState.RUNNING
            execution_order.append(process)
            
            # Process uses time quantum
            process.state = ProcessState.READY
            ready_queue.append(process)
        
        return execution_order


class PriorityScheduler(Scheduler):
    """Priority-based scheduling"""
    
    def schedule(self, processes: List[Process]) -> List[Process]:
        sorted_processes = sorted(processes, key=lambda p: p.priority, reverse=True)
        for p in sorted_processes:
            p.state = ProcessState.RUNNING
        return sorted_processes


class MemoryManager:
    """Memory management with paging"""
    
    def __init__(self, total_memory: int = 1000):
        self.total_memory = total_memory
        self.allocated = {}
        self.page_table = {}
    
    def allocate(self, process_id: int, size: int) -> bool:
        if sum(self.allocated.values()) + size <= self.total_memory:
            self.allocated[process_id] = size
            self.page_table[process_id] = size // 256  # Page size = 256
            return True
        return False
    
    def deallocate(self, process_id: int):
        if process_id in self.allocated:
            del self.allocated[process_id]
            del self.page_table[process_id]


# ============================================================================
# 9. SYMBOLIC & NUMERIC COMPUTING MODULE
# ============================================================================

class SymbolicExpression:
    """Symbolic mathematics"""
    
    def __init__(self, expr: str):
        self.expression = expr
        self.variables = self._extract_variables(expr)
    
    def _extract_variables(self, expr: str) -> set:
        """Extract variable names from expression"""
        import re
        return set(re.findall(r'[a-zA-Z_]\w*', expr))
    
    def evaluate(self, substitutions: Dict[str, float]) -> float:
        """Evaluate expression with substitutions"""
        try:
            return eval(self.expression, {"__builtins__": {}}, substitutions)
        except:
            return 0.0
    
    def differentiate(self, variable: str) -> str:
        """Symbolic differentiation (simplified)"""
        # Placeholder: real symbolic differentiation would use SymPy
        return f"d({self.expression})/d{variable}"


class LinearAlgebraOps:
    """Linear algebra operations"""
    
    @staticmethod
    def solve_linear_system(A: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Solve Ax = b"""
        try:
            return np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            return np.linalg.lstsq(A, b, rcond=None)[0]
    
    @staticmethod
    def eigendecomposition(A: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Compute eigenvalues and eigenvectors"""
        eigenvalues, eigenvectors = np.linalg.eig(A)
        return eigenvalues, eigenvectors
    
    @staticmethod
    def matrix_decomposition_svd(A: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Singular Value Decomposition"""
        U, S, Vt = np.linalg.svd(A)
        return U, S, Vt


class NumericalIntegration:
    """Numerical integration methods"""
    
    @staticmethod
    def trapezoidal_rule(f: Callable, a: float, b: float, n: int = 100) -> float:
        """Trapezoidal integration"""
        h = (b - a) / n
        result = 0.5 * (f(a) + f(b))
        for i in range(1, n):
            result += f(a + i * h)
        return result * h
    
    @staticmethod
    def simpsons_rule(f: Callable, a: float, b: float, n: int = 100) -> float:
        """Simpson's integration"""
        h = (b - a) / n
        result = f(a) + f(b)
        
        for i in range(1, n, 2):
            result += 4 * f(a + i * h)
        for i in range(2, n - 1, 2):
            result += 2 * f(a + i * h)
        
        return result * h / 3


print("✅ Extended Framework Modules Loaded")
print("   - Software Engineering")
print("   - AI/Machine Learning")
print("   - Networking")
print("   - Databases")
print("   - Parallel/Distributed Computing")
print("   - HCI")
print("   - Graphics")
print("   - Operating Systems")
print("   - Symbolic/Numeric Computing")
