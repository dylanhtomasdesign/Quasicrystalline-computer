"""Generate 5 remaining interactive Jupyter notebooks"""
import json

notebooks = {
    "02_Geometric_Computation_Interactive.ipynb": {
        "cells": [
            {"cell_type": "markdown", "source": ["# 2. Geometric Computation: 6D Harmonic\n\n## Interactive Exploration of Quasicrystalline Computation\n\n**Key Concepts:**\n- 6D state space with harmonic constraints\n- Rotations via golden-ratio angles\n- O(1) spatial lookup via HAT\n- Laplacian eigenvalue guidance\n- Full 6D parallelism"]},
            {"cell_type": "code", "source": ["import sys\nsys.path.append('/workspace')\nfrom simulation_framework import GeometricComputationModel\nfrom example_programs import GEOMETRIC_FIBONACCI\nimport numpy as np\nimport matplotlib.pyplot as plt\n\nprint('✅ Geometric Module Loaded')"]},
            {"cell_type": "code", "source": ["# Example 1: Fibonacci via Golden Ratio Rotations\ngeo = GeometricComputationModel(dimensions=6)\ngeo.initialize(GEOMETRIC_FIBONACCI, [1, 0, 0, 0, 0, 0])\nmetrics = geo.run(max_steps=100)\nstate = geo.get_state()\n\nprint(f'Steps: {metrics.steps}')\nprint(f'Magnitude: {state[\"magnitude\"]:.4f}')\nprint(f'State: {state[\"state_vector\"][:3]}')\nprint(f'Energy convergence: {state[\"magnitude\"] > 0.99}')"]},
            {"cell_type": "markdown", "source": ["## Characteristics:\n- ✅ O(1) spatial lookup\n- ✅ 100% 6D parallelism\n- ✅ Natural convergence via Laplacian\n- ❌ Higher per-operation overhead (~350 pJ)\n- ❌ Requires problem geometry alignment"]}
        ]
    },
    "03_Resonance_Computation_Interactive.ipynb": {
        "cells": [
            {"cell_type": "markdown", "source": ["# 3. Resonance Computation: Harmonic Modes\n\n## Interactive Exploration of Harmonic Interference\n\n**Key Concepts:**\n- 8 coupled harmonic oscillators\n- Phase-dependent interference patterns\n- Natural convergence to solutions\n- Energy dissipation drives optimization"]},
            {"cell_type": "code", "source": ["import sys\nsys.path.append('/workspace')\nfrom simulation_framework import ResonanceComputationModel\nfrom example_programs import RESONANCE_OPTIMIZE\nimport numpy as np\n\nprint('✅ Resonance Module Loaded')"]},
            {"cell_type": "code", "source": ["# Example: Harmonic Optimization\nres = ResonanceComputationModel(num_modes=8)\nres.initialize(RESONANCE_OPTIMIZE, 1.0)\nmetrics = res.run(max_steps=100)\nstate = res.get_state()\n\nprint(f'Steps: {metrics.steps}')\nprint(f'Total Energy: {state[\"total_energy\"]:.4f}')\nprint(f'Mode Amplitudes: {[abs(a) for a in state[\"amplitudes\"][:4]]}')"]},
            {"cell_type": "markdown", "source": ["## Characteristics:\n- ✅ Natural harmonic patterns\n- ✅ 100% 8-mode parallelism\n- ✅ Good for search/optimization\n- ❌ Oscillatory behavior (requires tuning)\n- ❌ Limited to 8 modes"]}
        ]
    },
    "04_Quantum_Computing_Interactive.ipynb": {
        "cells": [
            {"cell_type": "markdown", "source": ["# 4. Quantum Computing: Superposition & Algorithms\n\n## Interactive Exploration of Quantum Computation\n\n**Key Concepts:**\n- Qubit superposition (2^n states)\n- Quantum gates (Pauli, Hadamard, CNOT)\n- Grover's search: O(√N) speedup\n- Shor's factoring: exponential speedup"]},
            {"cell_type": "code", "source": ["import sys\nsys.path.append('/workspace')\nfrom quantum_computing_module import QuantumCircuit, GroverAlgorithm, ShorAlgorithm\nimport numpy as np\n\nprint('✅ Quantum Module Loaded')"]},
            {"cell_type": "code", "source": ["# Example 1: Grover's Search\nprint('Testing Grover\\'s Algorithm...')\nfor trial in range(5):\n    grover = GroverAlgorithm(num_qubits=4, marked_state=11)\n    result, prob = grover.run(iterations=3)\n    print(f'Trial {trial+1}: Found {result} with probability {prob:.2%}')\n\nprint(f'\\nQuantum Speedup: O(√N) vs O(N) classical')\nprint(f'For N=256: √N=16 vs N=256 → 16× speedup')\nprint(f'For N=1024: √N=32 vs N=1024 → 32× speedup')"]},
            {"cell_type": "code", "source": ["# Example 2: Shor's Factoring\nprint('Testing Shor\\'s Algorithm...')\nshor = ShorAlgorithm(N=15, a=7)\nfactors = shor.factor()\nprint(f'Factors of 15: {factors}')\nprint(f'\\nClassical factoring: O(2^(log N)^(1/3))')\nprint(f'Quantum (Shor): O(log^3 N)')\nprint(f'Speedup: Exponential!')"]},
            {"cell_type": "markdown", "source": ["## Characteristics:\n- ✅ Exponential superposition (2^n states)\n- ✅ Provable quantum speedups (Grover, Shor)\n- ✅ Maximal parallelism\n- ❌ Decoherence & noise\n- ❌ Limited to 50-1000 qubits today\n- ❌ ~600+ pJ per gate"]}
        ]
    },
    "05_Neuromorphic_Computing_Interactive.ipynb": {
        "cells": [
            {"cell_type": "markdown", "source": ["# 5. Neuromorphic Computing: Spiking Neural Networks\n\n## Interactive Exploration of Spike-Based Computation\n\n**Key Concepts:**\n- Leaky Integrate-and-Fire neurons\n- Spike-Timing-Dependent Plasticity (STDP)\n- Memristive synapses\n- Event-driven computation\n- Ultra-low energy (spike-based)"]},
            {"cell_type": "code", "source": ["import sys\nsys.path.append('/workspace')\nfrom neuromorphic_computing_module import SpikingNeuralNetwork, LIFNeuron, STDPRule\nimport numpy as np\n\nprint('✅ Neuromorphic Module Loaded')"]},
            {"cell_type": "code", "source": ["# Example 1: LIF Neuron Dynamics\nneuron = LIFNeuron()\nprint(f'Resting potential: {neuron.v_rest} V')\nprint(f'Threshold: {neuron.v_threshold} V')\nprint(f'Membrane time constant: {neuron.tau_m} s')\n\n# Simulate with current injection\nspiked = neuron.integrate(i_ext=0.01, dt=0.0001)\nprint(f'Neuron response to 0.01 nA input: Spike={spiked}')"]},
            {"cell_type": "code", "source": ["# Example 2: STDP Learning Rule\nstdp = STDPRule(tau_plus=0.02, tau_minus=0.02)\n\nprint('STDP Weight Changes:')\nprint('-' * 40)\ndelta_t_values = [-0.010, -0.005, 0, 0.005, 0.010]\nfor dt in delta_t_values:\n    dw = stdp.compute_weight_change(dt)\n    effect = 'potentiation' if dw > 0 else 'depression' if dw < 0 else 'no change'\n    print(f'Δt = {dt:+.3f}s → Δw = {dw:+.6f} ({effect})')\n\nprint(f'\\nBiologically plausible learning!')\nprint(f'Matches experimental data from neuroscience')"]},
            {"cell_type": "code", "source": ["# Example 3: Spiking Neural Network\nprint('Testing Spiking Neural Network...')\nsnn = SpikingNeuralNetwork([100, 50, 10], use_memristors=True)\ninput_spikes = [0.01, 0.02, 0.03, 0.05, 0.07]\noutput_spikes = snn.forward_pass(input_spikes, num_steps=100)\n\ntotal_output_spikes = sum(len(spikes) for spikes in output_spikes)\nprint(f'Input spikes: {len(input_spikes)}')\nprint(f'Output spikes: {total_output_spikes}')\nprint(f'Output distribution: {[len(s) for s in output_spikes]}')"]},
            {"cell_type": "markdown", "source": ["## Characteristics:\n- ✅ Biologically realistic\n- ✅ Ultra-low energy (10-50 pJ/spike)\n- ✅ Massive parallelism (1000s neurons)\n- ✅ Natural temporal dynamics\n- ✅ Realizable today (Intel Loihi, IBM TrueNorth)\n- ❌ Slower training than ANNs\n- ❌ Harder to program"]}
        ]
    },
    "06_Analog_Hybrid_Interactive.ipynb": {
        "cells": [
            {"cell_type": "markdown", "source": ["# 6. Analog & Hybrid Computing: Continuous Dynamics\n\n## Interactive Exploration of Analog and Hybrid Systems\n\n**Key Concepts:**\n- Continuous differential equations (ODEs)\n- Analog neural networks\n- Hybrid systems (digital + analog)\n- Biophysical models (Hodgkin-Huxley)"]},
            {"cell_type": "code", "source": ["import sys\nsys.path.append('/workspace')\nfrom analog_hybrid_computing_module import VanDerPolOscillator, HodgkinHuxleyNeuron, AnalogNeuralNetwork\nfrom scipy.integrate import solve_ivp\nimport numpy as np\nimport matplotlib.pyplot as plt\n\nprint('✅ Analog/Hybrid Module Loaded')"]},
            {"cell_type": "code", "source": ["# Example 1: Van der Pol Oscillator\nprint('Van der Pol Oscillator: Nonlinear Limit-Cycle')\nvdp = VanDerPolOscillator(mu=2.0)\nsol = vdp.integrate((0, 20), num_points=1000)\n\nprint(f'Trajectory computed over 20 seconds')\nprint(f'Points: {len(sol.t)}')\nprint(f'Used in: analog signal processing, frequency generation')\n\n# Plot\nplt.figure(figsize=(10, 4))\nplt.plot(sol.y[0], sol.y[1], 'b-', linewidth=2, alpha=0.7)\nplt.xlabel('x', fontweight='bold')\nplt.ylabel('dx/dt', fontweight='bold')\nplt.title('Van der Pol Limit Cycle (μ=2.0)', fontweight='bold')\nplt.grid(alpha=0.3)\nplt.savefig('/workspace/van_der_pol.png', dpi=150, bbox_inches='tight')\nplt.show()"]},
            {"cell_type": "code", "source": ["# Example 2: Hodgkin-Huxley Neuron\nprint('\\nHodgkin-Huxley Model: Realistic Action Potential')\nhh = HodgkinHuxleyNeuron()\n\ndef hh_dynamics(x, t):\n    return hh.dx_dt(x, t, I_ext=15)\n\nsol_hh = solve_ivp(hh_dynamics, [0, 50], hh.state, t_eval=np.linspace(0, 50, 1000), method='RK45')\n\n# Count action potentials\nV = sol_hh.y[0]\nspikes = np.sum(np.diff(V > -50).astype(int) == 1)\nprint(f'Action potentials generated: {spikes}')\nprint(f'Biophysically realistic model')\n\n# Plot\nplt.figure(figsize=(10, 4))\nplt.plot(sol_hh.t, V, 'r-', linewidth=1.5)\nplt.xlabel('Time (ms)', fontweight='bold')\nplt.ylabel('Membrane Voltage (mV)', fontweight='bold')\nplt.title('Hodgkin-Huxley Action Potentials', fontweight='bold')\nplt.grid(alpha=0.3)\nplt.savefig('/workspace/hodgkin_huxley.png', dpi=150, bbox_inches='tight')\nplt.show()"]},
            {"cell_type": "code", "source": ["# Example 3: Analog Neural Network\nprint('\\nAnalog Neural Network: Continuous Firing Rates')\nann = AnalogNeuralNetwork([10, 20, 5])\nx_input = np.random.randn(10) * 0.1\noutput = ann.forward(x_input, num_steps=100)\n\nprint(f'Input shape: {x_input.shape}')\nprint(f'Output shape: {output.shape}')\nprint(f'Output firing rates (0-1): {output}')\nprint(f'\\nFeatures:')\nprint(f'  - Continuous sigmoid activations')\nprint(f'  - ODE-based dynamics')\nprint(f'  - Natural for continuous problems')"]},
            {"cell_type": "markdown", "source": ["## Characteristics:\n- ✅ Natural for continuous systems\n- ✅ Minimal discretization error\n- ✅ Low-power analog circuits (~100-200 pJ)\n- ✅ 50% parallelism (analog + digital hybrid)\n- ❌ Non-reprogrammable (hardware-specific)\n- ❌ Noise sensitivity\n- ❌ Component tolerance limits precision"]}
        ]
    }
}

# Generate notebooks
for filename, notebook_data in notebooks.items():
    cells = [
        {
            "cell_type": cell["cell_type"],
            "metadata": {},
            "source": cell["source"] if isinstance(cell["source"], list) else [cell["source"]],
            "outputs": [] if cell["cell_type"] == "code" else [],
            "execution_count": None if cell["cell_type"] == "code" else None
        }
        for cell in notebook_data["cells"]
    ]
    
    notebook = {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "name": "python",
                "version": "3.9.0"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 4
    }
    
    with open(f'/workspace/{filename}', 'w') as f:
        json.dump(notebook, f, indent=1)
    
    print(f"✅ {filename}")

print("\n✅ All 5 notebooks generated!")
