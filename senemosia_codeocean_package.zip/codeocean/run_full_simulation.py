"""
Complete end-to-end simulation with all models and visualizations
Run this to execute the full benchmark and generate all outputs
"""

import sys
import numpy as np
from simulation_framework import create_model, TuringMachine, GeometricComputationModel, ResonanceComputationModel
from example_programs import (
    TURING_INCREMENT, TURING_PALINDROME, TURING_COUNTER,
    GEOMETRIC_FIBONACCI, GEOMETRIC_SORT, GEOMETRIC_PATHFIND,
    RESONANCE_PATTERN_MATCH, RESONANCE_SEARCH, RESONANCE_OPTIMIZE
)
from benchmark_suite import ModelComparison, AnalysisTools
from visualization import ExecutionVisualizer, ComparativeAnalysis, generate_all_visualizations


def main():
    print("\n" + "=" * 80)
    print("UNCONVENTIONAL COMPUTING MODELS - FULL SIMULATION SUITE")
    print("=" * 80 + "\n")
    
    comparison = ModelComparison()
    analyzer = AnalysisTools()
    visualizer = ExecutionVisualizer()
    
    metrics_dict = {}
    traces_dict = {
        'turing': None,
        'geometric': None,
        'resonance': None
    }
    
    # ========================================================================
    # TEST SUITE 1: TURING MACHINE
    # ========================================================================
    print("\n" + "-" * 80)
    print("TURING MACHINE TESTS")
    print("-" * 80 + "\n")
    
    # Test 1a: Binary Increment
    print("1. Binary Increment: 101 → 110")
    tm_incr = TuringMachine()
    tm_incr.initialize(TURING_INCREMENT, "101")
    metrics_incr = tm_incr.run(max_steps=100)
    metrics_dict['Turing: Increment'] = metrics_incr
    traces_dict['turing'] = metrics_incr.trace
    print(f"   Output: {metrics_incr.output}")
    print(f"   Steps: {metrics_incr.steps}, Time: {metrics_incr.time_elapsed*1000:.3f}ms")
    print(f"   Success: {'✓' if metrics_incr.halted else '✗'}")
    
    # Test 1b: Palindrome check
    print("\n2. Palindrome Checker: 'racecar'")
    tm_palin = TuringMachine()
    tm_palin.initialize(TURING_PALINDROME, "racecar")
    metrics_palin = tm_palin.run(max_steps=500)
    metrics_dict['Turing: Palindrome'] = metrics_palin
    print(f"   Output: {metrics_palin.output}")
    print(f"   Steps: {metrics_palin.steps}, Time: {metrics_palin.time_elapsed*1000:.3f}ms")
    print(f"   Success: {'✓' if metrics_palin.halted else '✗'}")
    
    # Test 1c: String length counter
    print("\n3. String Length Counter: '101010'")
    tm_count = TuringMachine()
    tm_count.initialize(TURING_COUNTER, "101010")
    metrics_count = tm_count.run(max_steps=100)
    metrics_dict['Turing: Counter'] = metrics_count
    print(f"   Output length: {len(metrics_count.output)}")
    print(f"   Steps: {metrics_count.steps}, Time: {metrics_count.time_elapsed*1000:.3f}ms")
    
    # ========================================================================
    # TEST SUITE 2: GEOMETRIC MODEL
    # ========================================================================
    print("\n" + "-" * 80)
    print("GEOMETRIC COMPUTATION MODEL TESTS")
    print("-" * 80 + "\n")
    
    # Test 2a: Fibonacci rotations
    print("1. Fibonacci via Golden Ratio Rotations")
    geo_fib = GeometricComputationModel(dimensions=6)
    geo_fib.initialize(GEOMETRIC_FIBONACCI, [1, 0, 0, 0, 0, 0])
    metrics_geo_fib = geo_fib.run(max_steps=100)
    metrics_dict['Geometric: Fibonacci'] = metrics_geo_fib
    traces_dict['geometric'] = metrics_geo_fib.trace
    state_fib = geo_fib.get_state()
    print(f"   Final state: {np.array(state_fib['state_vector'])[:3]}")
    print(f"   Magnitude: {state_fib['magnitude']:.4f}")
    print(f"   Steps: {metrics_geo_fib.steps}, Time: {metrics_geo_fib.time_elapsed*1000:.3f}ms")
    
    # Test 2b: Sorting via projection
    print("\n2. Sorting via Geometric Projection")
    geo_sort = GeometricComputationModel(dimensions=6)
    geo_sort.initialize(GEOMETRIC_SORT, [5, 3, 1, 4, 2])
    metrics_geo_sort = geo_sort.run(max_steps=100)
    metrics_dict['Geometric: Sort'] = metrics_geo_sort
    state_sort = geo_sort.get_state()
    print(f"   Output sequence: {metrics_geo_sort.output}")
    print(f"   Steps: {metrics_geo_sort.steps}")
    
    # Test 2c: Path finding
    print("\n3. Path Finding via Geometric Convergence")
    geo_path = GeometricComputationModel(dimensions=6)
    geo_path.initialize(GEOMETRIC_PATHFIND, [0, 0, 0, 0, 0, 0])
    metrics_geo_path = geo_path.run(max_steps=100)
    metrics_dict['Geometric: Pathfind'] = metrics_geo_path
    state_path = geo_path.get_state()
    print(f"   Final position: {np.array(state_path['state_vector'])[:3]}")
    print(f"   Steps: {metrics_geo_path.steps}")
    
    # ========================================================================
    # TEST SUITE 3: RESONANCE MODEL
    # ========================================================================
    print("\n" + "-" * 80)
    print("RESONANCE COMPUTATION MODEL TESTS")
    print("-" * 80 + "\n")
    
    # Test 3a: Pattern matching
    print("1. Pattern Matching via Harmonic Resonance")
    res_pattern = ResonanceComputationModel(num_modes=8)
    res_pattern.initialize(RESONANCE_PATTERN_MATCH, 1.0)
    metrics_res_pattern = res_pattern.run(max_steps=100)
    metrics_dict['Resonance: Pattern'] = metrics_res_pattern
    traces_dict['resonance'] = metrics_res_pattern.trace
    state_pattern = res_pattern.get_state()
    print(f"   Output: {metrics_res_pattern.output}")
    print(f"   Total energy: {state_pattern['total_energy']:.4f}")
    print(f"   Steps: {metrics_res_pattern.steps}")
    
    # Test 3b: Search
    print("\n2. Search via Mode Coupling")
    res_search = ResonanceComputationModel(num_modes=8)
    res_search.initialize(RESONANCE_SEARCH, 1.0)
    metrics_res_search = res_search.run(max_steps=100)
    metrics_dict['Resonance: Search'] = metrics_res_search
    state_search = res_search.get_state()
    print(f"   Output: {metrics_res_search.output}")
    print(f"   Total energy: {state_search['total_energy']:.4f}")
    print(f"   Steps: {metrics_res_search.steps}")
    
    # Test 3c: Optimization
    print("\n3. Optimization via Harmonic Evolution")
    res_optim = ResonanceComputationModel(num_modes=8)
    res_optim.initialize(RESONANCE_OPTIMIZE, 1.0)
    metrics_res_optim = res_optim.run(max_steps=100)
    metrics_dict['Resonance: Optimize'] = metrics_res_optim
    state_optim = res_optim.get_state()
    print(f"   Output: {metrics_res_optim.output}")
    print(f"   Mode amplitudes: {[f'{abs(m):.2f}' for m in state_optim['modes'][:4]]}")
    print(f"   Steps: {metrics_res_optim.steps}")
    
    # ========================================================================
    # COMPARATIVE ANALYSIS
    # ========================================================================
    print("\n" + "=" * 80)
    print("COMPARATIVE ANALYSIS")
    print("=" * 80 + "\n")
    
    # Calculate efficiency metrics
    total_steps = sum(m.steps for m in metrics_dict.values())
    total_time = sum(m.time_elapsed for m in metrics_dict.values())
    
    print(f"Total Executions: {len(metrics_dict)}")
    print(f"Total Steps: {total_steps}")
    print(f"Total Time: {total_time*1000:.2f} ms")
    print(f"Average Steps: {total_steps/len(metrics_dict):.1f}")
    print(f"Average Time: {total_time/len(metrics_dict)*1000:.3f} ms")
    
    # Find extremes
    fastest_name = min(metrics_dict.items(), key=lambda x: x[1].steps)[0]
    slowest_name = max(metrics_dict.items(), key=lambda x: x[1].steps)[0]
    fastest_time = min(metrics_dict.items(), key=lambda x: x[1].time_elapsed)[0]
    slowest_time = max(metrics_dict.items(), key=lambda x: x[1].time_elapsed)[0]
    
    print(f"\n✓ Fewest steps: {fastest_name} ({metrics_dict[fastest_name].steps})")
    print(f"✗ Most steps: {slowest_name} ({metrics_dict[slowest_name].steps})")
    print(f"✓ Fastest: {fastest_time} ({metrics_dict[fastest_time].time_elapsed*1000:.3f} ms)")
    print(f"✗ Slowest: {slowest_time} ({metrics_dict[slowest_time].time_elapsed*1000:.3f} ms)")
    
    speedup = metrics_dict[slowest_name].steps / (metrics_dict[fastest_name].steps or 1)
    print(f"\nSpeedup Factor: {speedup:.2f}x")
    
    # ========================================================================
    # TRACE ANALYSIS
    # ========================================================================
    print("\n" + "=" * 80)
    print("EXECUTION TRACE ANALYSIS")
    print("=" * 80 + "\n")
    
    if traces_dict['turing']:
        print("Turing Machine (Binary Increment):")
        trace_analysis = analyzer.trace_path_analysis(traces_dict['turing'], 'turing')
        print(f"  Trace length: {trace_analysis['trace_length']}")
        print(f"  Unique states: {trace_analysis['unique_states']}")
    
    if traces_dict['geometric']:
        print("\nGeometric Model (Fibonacci):")
        conv_analysis = analyzer.convergence_analysis(traces_dict['geometric'], 'geometric')
        print(f"  Convergence type: {conv_analysis.get('type', 'N/A')}")
        print(f"  Final magnitude: {conv_analysis.get('final_magnitude', 'N/A')}")
        print(f"  Converged: {conv_analysis.get('converged', 'N/A')}")
    
    if traces_dict['resonance']:
        print("\nResonance Model (Optimization):")
        res_analysis = analyzer.convergence_analysis(traces_dict['resonance'], 'resonance')
        print(f"  Analysis type: {res_analysis.get('type', 'N/A')}")
        print(f"  Final energy: {res_analysis.get('final_energy', 'N/A')}")
        print(f"  Stable: {res_analysis.get('stable', 'N/A')}")
    
    # ========================================================================
    # VISUALIZATIONS
    # ========================================================================
    print("\n" + "=" * 80)
    print("GENERATING VISUALIZATIONS")
    print("=" * 80 + "\n")
    
    generate_all_visualizations(
        metrics_dict,
        turing_trace=traces_dict['turing'],
        geometric_trace=traces_dict['geometric'],
        resonance_trace=traces_dict['resonance']
    )
    
    # ========================================================================
    # EXPORT RESULTS
    # ========================================================================
    print("\n" + "=" * 80)
    print("EXPORTING RESULTS")
    print("=" * 80 + "\n")
    
    comparison.export_json('/workspace/simulation_results.json')
    
    print("\n" + "=" * 80)
    print("✓ SIMULATION COMPLETE")
    print("=" * 80)
    print("\nGenerated files:")
    print("  - simulation_results.json (comprehensive results)")
    print("  - step_progression.png (metric comparison)")
    print("  - turing_tape_evolution.png (Turing machine tape states)")
    print("  - geometric_state_space.png (geometric model 3D trajectory)")
    print("  - resonance_modes.png (resonance model energy evolution)")
    print("  - analysis_summary.txt (detailed report)")
    print("\n")


if __name__ == "__main__":
    main()
