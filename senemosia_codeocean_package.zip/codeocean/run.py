#!/usr/bin/env python3
"""
Senemosìa Punto Zero v2.0 - Main Runner
Orchestrating Heterogeneous Computing Substrates

This script runs the comprehensive benchmark suite comparing
all 6 computational paradigms.
"""

import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))

def main():
    print("=" * 80)
    print("SENEMOSÌA PUNTO ZERO v2.0")
    print("Unified 6-Paradigm Heterogeneous Computing Framework")
    print("=" * 80)
    print()
    
    # Try to import the simulation framework
    try:
        from simulation_framework import SimulationFramework
        print("[OK] Simulation Framework loaded")
    except ImportError as e:
        print(f"[WARN] Could not load simulation_framework: {e}")
    
    # Try to run benchmark suite
    try:
        from benchmark_suite import BenchmarkSuite
        print("[OK] Benchmark Suite loaded")
        
        # Run benchmarks
        suite = BenchmarkSuite()
        print("\n[RUNNING] Executing benchmark suite...")
        results = suite.run_all()
        print("\n[COMPLETE] Benchmark Results:")
        print(results.summary())
        
    except ImportError as e:
        print(f"[WARN] Could not load benchmark_suite: {e}")
        print("\nRunning basic demonstration instead...")
        
        try:
            from simulation_framework import demonstrate_all_paradigms
            demonstrate_all_paradigms()
        except Exception as e:
            print(f"[ERROR] Demo failed: {e}")
    
    print("\n" + "=" * 80)
    print("SENEMOSÌA PUNTO ZERO - EXECUTION COMPLETE")
    print("=" * 80)

if __name__ == "__main__":
    main()
