# Quick Start: 5 Minutes to Simulation

## Step 1: Run the Full Simulation (1 minute)

```bash
cd /workspace
python3 run_full_simulation.py
```

**You'll see:**
- 9 benchmark tests execute (3 models × 3 tests each)
- Real-time output of results
- 6 PNG visualizations generated
- JSON data file created

## Step 2: View Results (2 minutes)

**Check the workspace sidebar** for these files:

| File | What It Shows |
|------|---------------|
| `step_progression.png` | 4-panel metric comparison (steps, time, memory, transitions) |
| `turing_tape_evolution.png` | How Turing machine tape evolves |
| `geometric_state_space.png` | 3D trajectory of geometric state vector |
| `resonance_modes.png` | Energy and mode amplitudes over time |
| `analysis_summary.txt` | Detailed text report |
| `simulation_results.json` | Raw data (all traces) |

## Step 3: Try Your Own Program (2 minutes)

### Test 1: Modify a Turing Program

Edit `example_programs.py`, change the binary number:

```python
# Line in run_full_simulation.py:
metrics_incr = tm_incr.run(max_steps=100)  # Existing

# Change input:
tm_incr.initialize(TURING_INCREMENT, "1111")  # Instead of "101"
```

Re-run:
```bash
python3 run_full_simulation.py
```

See how the output changes!

### Test 2: Create a Geometric Program

Add to `example_programs.py`:

```python
GEOMETRIC_CUSTOM = """
# Your custom geometric algorithm
ROTATE: 0,1,0.5
ROTATE: 1,2,0.5
SCALE: 2.0
THRESHOLD: 0,0.5 -> output
"""
```

Then test it in Python:

```python
from simulation_framework import create_model
from example_programs import GEOMETRIC_CUSTOM

geo = create_model('geometric', dimensions=6)
geo.initialize(GEOMETRIC_CUSTOM, [1, 0, 0, 0, 0, 0])
metrics = geo.run()
print(f"Steps: {metrics.steps}, Output: {metrics.output}")
print(f"Final state: {geo.get_state()['state_vector'][:3]}")
```

### Test 3: Create a Resonance Program

```python
RESONANCE_CUSTOM = """
EXCITE: 0,2.0,0.0
EXCITE: 1,1.0,1.57
INTERFERE: 0,1
COUPLE: 0,1,0.3
NORMALIZE
MEASURE: 0,0.7 -> output
"""
```

Test similarly:

```python
from simulation_framework import create_model
from example_programs import RESONANCE_CUSTOM

res = create_model('resonance', num_modes=8)
res.initialize(RESONANCE_CUSTOM, 1.0)
metrics = res.run()
print(f"Energy: {res.get_state()['total_energy']:.4f}")
```

---

## Understanding the Output

### `step_progression.png` (4 panels)

**Panel 1 (top-left): Steps**
- Bar height = number of operations
- Turing: Discrete (few steps)
- Geometric: Parallel (same steps, but all 6D at once)
- Resonance: Medium complexity

**Panel 2 (top-right): Time**
- Turing: Fastest (simple discrete ops)
- Geometric: Slower (matrix multiplication)
- Resonance: Complex numbers slower

**Panel 3 (bottom-left): Memory**
- How many state read/write operations
- Correlates with steps

**Panel 4 (bottom-right): State Transitions**
- How many unique states explored
- Turing: Finite state machine (few)
- Geometric/Resonance: All dimensions active (many)

### `turing_tape_evolution.png` (4 snapshots)

Shows tape at 4 points during execution:
- **Gold square** = head position
- **White square** = written value
- **Green square** = blank
- **Red arrow** = head direction

### `geometric_state_space.png` (4 plots)

1. **Magnitude**: How the vector length changes (convergence)
2. **3D Plot**: Trajectory in 3D space (first 3 dimensions)
3. **Distance**: Euclidean distance from origin (settling)
4. **Components**: How each dimension evolves separately

### `resonance_modes.png` (4 plots)

1. **Energy**: Total system energy over time (should stabilize)
2. **Amplitudes**: How "loud" each mode is
3. **Phases**: Rotation angle of each mode (radians)
4. **Spectrum**: Final distribution of energy across modes

---

## Key Metrics Explained

| Metric | What It Means | Lower/Higher? |
|--------|---------------|---------------|
| **Steps** | Operations executed | Lower = more efficient |
| **Time (ms)** | Wall-clock execution | Lower = faster |
| **Memory Ops** | State accesses | Lower = less activity |
| **State Transitions** | Unique states visited | Indicates exploration |
| **Magnitude** (Geometric) | Vector length | Convergence = constant |
| **Energy** (Resonance) | Sum of mode amplitudes² | Stable = oscillatory |

---

## 5 Experiments to Try

### 1. Binary Increment with Different Input Lengths
**Hypothesis:** Longer binary strings take more steps
```python
inputs = ['1', '11', '111', '1111', '11111']
for inp in inputs:
    # Test and plot
```

### 2. Geometric Rotations: Golden Ratio vs. Other Angles
**Hypothesis:** φ angle produces Fibonacci naturally
```python
# Change 1.0172 to 0.785 (π/4) and compare
```

### 3. Resonance: How Many Modes Do You Need?
**Hypothesis:** More modes = better pattern matching
```python
for num_modes in [4, 8, 16, 32]:
    res = create_model('resonance', num_modes=num_modes)
    # Compare convergence
```

### 4. Can Geometric Model Sort Better Than Turing?
**Hypothesis:** Dimensional parallelism helps sorting
```python
# Create sorting programs for both
# Compare steps for different array sizes
```

### 5. What's the Shortest Program for X?
**Hypothesis:** Each model has natural "fit" for problems
```python
# Try expressing: sum, increment, parity check
# in all 3 models
# Count steps per model
```

---

## Model Cheat Sheet

### Turing Machine
```
START: state_name
HALT: halt_state

state,read -> write,move,next_state
```
- `move`: L or R
- `read`/`write`: Any symbol (_=blank)
- Best for: String manipulation, parsing

### Geometric Model
```
ROTATE: dim1,dim2,angle
PROJECT: dimension
SCALE: factor
NORM
THRESHOLD: dim,value -> output
```
- Angle: Radians (e.g., 1.57 ≈ π/2)
- State: Always 6D vector
- Best for: Math-heavy, geometric problems

### Resonance Model
```
EXCITE: mode,freq,phase
INTERFERE: mode1,mode2
COUPLE: mode1,mode2,strength
MEASURE: mode,thresh -> output
NORMALIZE
```
- Modes: 0-7 (complex-valued)
- Strength: 0-1 (coupling factor)
- Best for: Pattern matching, search

---

## Troubleshooting

**Q: ImportError: No module named 'numpy'**
```bash
pip install numpy matplotlib seaborn
```

**Q: Turing machine test halts with 0 steps**
- Program may have no matching transition for input
- Check `initialize()` call and program syntax

**Q: Geometric/Resonance tests produce all zeros**
- Check initial state (should be non-zero)
- Verify THRESHOLD values make sense for magnitudes

**Q: PNG files not showing up**
- Check working directory: `pwd` should show `/workspace`
- Files saved to `/workspace/*.png`

**Q: JSON export fails**
- Try running without export: Comment out line in `run_full_simulation.py`

---

## Next Level

Once comfortable:

1. **Add a 4th model** (Quantum, Neural, etc.)
2. **Design custom benchmarks** for specific problem class
3. **Analyze traces programmatically** (extract patterns)
4. **Create new visualizations** (heat maps, animations)
5. **Write research paper** on your findings!

---

## Files You'll Use Most

| File | Purpose |
|------|---------|
| `run_full_simulation.py` | **START HERE** - Execute all tests |
| `example_programs.py` | Modify programs, add your own |
| `simulation_framework.py` | Add new model (subclass ComputationModel) |
| `visualization.py` | Create custom plots |
| `SIMULATION_GUIDE.md` | Full documentation |
| `README.md` | Theory & API reference |

---

## Checklist ✓

- [ ] Run `python3 run_full_simulation.py`
- [ ] View PNG files in workspace sidebar
- [ ] Read `analysis_summary.txt`
- [ ] Modify one program and re-run
- [ ] Try creating a custom program
- [ ] Inspect JSON data
- [ ] Read one visualization carefully
- [ ] Ask: "What would make Model X faster?"

**You're now ready to explore unconventional computing!**
