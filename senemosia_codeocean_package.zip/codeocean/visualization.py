"""
Visualization and analysis tools for computational model simulations
Generates plots, graphs, and interactive analyses
"""

import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
from typing import Dict, List, Any, Tuple
from simulation_framework import ExecutionMetrics
import seaborn as sns

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (14, 10)


class ExecutionVisualizer:
    """Visualize execution traces and metrics"""
    
    @staticmethod
    def plot_step_progression(metrics_dict: Dict[str, ExecutionMetrics], 
                             output_path: str = '/workspace/step_progression.png'):
        """Compare step counts across models"""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle('Computational Model Comparison: Execution Profiles', 
                     fontsize=16, fontweight='bold')
        
        models = list(metrics_dict.keys())
        steps = [m.steps for m in metrics_dict.values()]
        times = [m.time_elapsed * 1000 for m in metrics_dict.values()]  # ms
        memory = [m.memory_accesses for m in metrics_dict.values()]
        transitions = [m.state_transitions for m in metrics_dict.values()]
        
        # Plot 1: Steps comparison
        ax1 = axes[0, 0]
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1']
        bars1 = ax1.bar(models, steps, color=colors[:len(models)], alpha=0.7, edgecolor='black', linewidth=2)
        ax1.set_ylabel('Steps', fontsize=11, fontweight='bold')
        ax1.set_title('Execution Steps', fontsize=12, fontweight='bold')
        ax1.grid(axis='y', alpha=0.3)
        for bar, step in zip(bars1, steps):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height,
                    f'{int(step)}', ha='center', va='bottom', fontweight='bold')
        
        # Plot 2: Execution time
        ax2 = axes[0, 1]
        bars2 = ax2.bar(models, times, color=colors[:len(models)], alpha=0.7, edgecolor='black', linewidth=2)
        ax2.set_ylabel('Time (ms)', fontsize=11, fontweight='bold')
        ax2.set_title('Execution Time', fontsize=12, fontweight='bold')
        ax2.grid(axis='y', alpha=0.3)
        for bar, time in zip(bars2, times):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                    f'{time:.2f}', ha='center', va='bottom', fontsize=9, fontweight='bold')
        
        # Plot 3: Memory accesses
        ax3 = axes[1, 0]
        bars3 = ax3.bar(models, memory, color=colors[:len(models)], alpha=0.7, edgecolor='black', linewidth=2)
        ax3.set_ylabel('Memory Accesses', fontsize=11, fontweight='bold')
        ax3.set_title('Memory Operations', fontsize=12, fontweight='bold')
        ax3.grid(axis='y', alpha=0.3)
        for bar, mem in zip(bars3, memory):
            height = bar.get_height()
            ax3.text(bar.get_x() + bar.get_width()/2., height,
                    f'{int(mem)}', ha='center', va='bottom', fontweight='bold')
        
        # Plot 4: State transitions
        ax4 = axes[1, 1]
        bars4 = ax4.bar(models, transitions, color=colors[:len(models)], alpha=0.7, edgecolor='black', linewidth=2)
        ax4.set_ylabel('State Transitions', fontsize=11, fontweight='bold')
        ax4.set_title('State Space Exploration', fontsize=12, fontweight='bold')
        ax4.grid(axis='y', alpha=0.3)
        for bar, trans in zip(bars4, transitions):
            height = bar.get_height()
            ax4.text(bar.get_x() + bar.get_width()/2., height,
                    f'{int(trans)}', ha='center', va='bottom', fontweight='bold')
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Saved: {output_path}")
        plt.close()
    
    @staticmethod
    def plot_turing_tape_evolution(trace: List[Dict[str, Any]], 
                                   output_path: str = '/workspace/turing_tape_evolution.png'):
        """Visualize Turing machine tape state evolution"""
        if not trace or 'tape_snapshot' not in trace[0]:
            print("Cannot visualize: no tape snapshots in trace")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle('Turing Machine Tape Evolution', fontsize=16, fontweight='bold')
        
        # Sample key points in execution
        indices = [0, len(trace)//3, 2*len(trace)//3, len(trace)-1]
        
        for idx, ax_idx in enumerate(indices):
            ax = axes[idx // 2, idx % 2]
            
            if ax_idx >= len(trace):
                ax.text(0.5, 0.5, 'No data', ha='center', va='center', transform=ax.transAxes)
                continue
            
            step = trace[ax_idx]
            tape = step.get('tape_snapshot', {})
            head_pos = step.get('head_pos', 0)
            
            if not tape:
                ax.text(0.5, 0.5, 'Empty', ha='center', va='center', transform=ax.transAxes)
                continue
            
            min_pos = min(tape.keys()) if tape else 0
            max_pos = max(tape.keys()) if tape else 0
            
            # Draw tape cells
            for pos in range(min_pos - 2, max_pos + 3):
                symbol = tape.get(pos, '_')
                color = '#FFD700' if pos == head_pos else ('#E8F5E9' if symbol == '_' else '#FFFFFF')
                
                rect = FancyBboxPatch((pos - 0.4, -0.4), 0.8, 0.8, 
                                     boxstyle="round,pad=0.05", 
                                     edgecolor='black', facecolor=color, linewidth=2)
                ax.add_patch(rect)
                ax.text(pos, 0, symbol, ha='center', va='center', fontsize=10, fontweight='bold')
            
            # Draw head indicator
            if head_pos is not None:
                ax.arrow(head_pos, 0.7, 0, -0.3, head_width=0.2, head_length=0.15, 
                        fc='red', ec='red', linewidth=2)
            
            ax.set_xlim(min_pos - 3, max_pos + 3)
            ax.set_ylim(-1, 1.2)
            ax.set_aspect('equal')
            ax.axis('off')
            
            state = step.get('state', '?')
            ax.set_title(f'Step {ax_idx} | State: {state} | Head: {head_pos}', 
                        fontweight='bold', fontsize=10)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Saved: {output_path}")
        plt.close()
    
    @staticmethod
    def plot_geometric_state_space(trace: List[Dict[str, Any]], 
                                   output_path: str = '/workspace/geometric_state_space.png'):
        """Visualize geometric model state evolution in high-dimensional space"""
        if not trace or 'state_after' not in trace[0]:
            print("Cannot visualize: no state snapshots in trace")
            return
        
        fig = plt.figure(figsize=(14, 10))
        fig.suptitle('Geometric Computation Model: State Space Evolution', 
                    fontsize=16, fontweight='bold')
        
        # Extract state vectors and magnitudes
        states = np.array([t['state_after'] for t in trace])
        magnitudes = np.array([np.linalg.norm(s) for s in states])
        
        # Plot 1: Magnitude evolution
        ax1 = plt.subplot(2, 2, 1)
        ax1.plot(magnitudes, linewidth=2.5, color='#45B7D1', marker='o', markersize=3, alpha=0.7)
        ax1.fill_between(range(len(magnitudes)), magnitudes, alpha=0.3, color='#45B7D1')
        ax1.set_xlabel('Step', fontweight='bold')
        ax1.set_ylabel('State Vector Magnitude', fontweight='bold')
        ax1.set_title('Magnitude Convergence', fontweight='bold')
        ax1.grid(alpha=0.3)
        
        # Plot 2: First 3 dimensions projection
        if states.shape[1] >= 3:
            ax2 = plt.subplot(2, 2, 2, projection='3d')
            ax2.plot(states[:, 0], states[:, 1], states[:, 2], 
                    linewidth=2, color='#4ECDC4', alpha=0.7)
            ax2.scatter(states[0, 0], states[0, 1], states[0, 2], 
                       color='green', s=100, marker='o', label='Start', zorder=5)
            ax2.scatter(states[-1, 0], states[-1, 1], states[-1, 2], 
                       color='red', s=100, marker='s', label='End', zorder=5)
            ax2.set_xlabel('Dim 0', fontweight='bold')
            ax2.set_ylabel('Dim 1', fontweight='bold')
            ax2.set_zlabel('Dim 2', fontweight='bold')
            ax2.set_title('State Trajectory (3D Projection)', fontweight='bold')
            ax2.legend()
        
        # Plot 3: Distance from origin
        ax3 = plt.subplot(2, 2, 3)
        distances = np.sqrt(np.sum(states**2, axis=1))
        ax3.plot(distances, linewidth=2.5, color='#FF6B6B', marker='o', markersize=3, alpha=0.7)
        ax3.fill_between(range(len(distances)), distances, alpha=0.3, color='#FF6B6B')
        ax3.set_xlabel('Step', fontweight='bold')
        ax3.set_ylabel('Distance from Origin', fontweight='bold')
        ax3.set_title('Euclidean Distance Evolution', fontweight='bold')
        ax3.grid(alpha=0.3)
        
        # Plot 4: Dimension-wise contribution
        if states.shape[1] >= 3:
            ax4 = plt.subplot(2, 2, 4)
            for dim in range(min(3, states.shape[1])):
                ax4.plot(states[:, dim], linewidth=2, marker='o', markersize=2, 
                        label=f'Dim {dim}', alpha=0.7)
            ax4.set_xlabel('Step', fontweight='bold')
            ax4.set_ylabel('Component Value', fontweight='bold')
            ax4.set_title('Dimension-wise Evolution', fontweight='bold')
            ax4.legend()
            ax4.grid(alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Saved: {output_path}")
        plt.close()
    
    @staticmethod
    def plot_resonance_modes(trace: List[Dict[str, Any]], 
                            output_path: str = '/workspace/resonance_modes.png'):
        """Visualize resonance model mode evolution"""
        if not trace or 'modes_after' not in trace[0]:
            print("Cannot visualize: no mode snapshots in trace")
            return
        
        fig = plt.figure(figsize=(14, 10))
        fig.suptitle('Resonance Computation Model: Mode Evolution', 
                    fontsize=16, fontweight='bold')
        
        # Extract mode data
        modes_list = [t['modes_after'] for t in trace]
        energies = np.array([t['total_energy'] for t in trace])
        
        # Plot 1: Total energy
        ax1 = plt.subplot(2, 2, 1)
        ax1.plot(energies, linewidth=2.5, color='#FF6B6B', marker='o', markersize=3, alpha=0.7)
        ax1.fill_between(range(len(energies)), energies, alpha=0.3, color='#FF6B6B')
        ax1.set_xlabel('Step', fontweight='bold')
        ax1.set_ylabel('Total Energy', fontweight='bold')
        ax1.set_title('System Energy Evolution', fontweight='bold')
        ax1.grid(alpha=0.3)
        
        # Plot 2: Amplitudes per mode
        if modes_list:
            ax2 = plt.subplot(2, 2, 2)
            num_modes = len(modes_list[0])
            for mode_idx in range(num_modes):
                amplitudes = [abs(m[mode_idx]) for m in modes_list]
                ax2.plot(amplitudes, linewidth=1.5, marker='o', markersize=2, 
                        label=f'Mode {mode_idx}', alpha=0.6)
            ax2.set_xlabel('Step', fontweight='bold')
            ax2.set_ylabel('Amplitude', fontweight='bold')
            ax2.set_title('Mode Amplitudes Over Time', fontweight='bold')
            ax2.legend(ncol=2, fontsize=8)
            ax2.grid(alpha=0.3)
        
        # Plot 3: Phase evolution
        if modes_list:
            ax3 = plt.subplot(2, 2, 3)
            num_modes = min(4, len(modes_list[0]))
            for mode_idx in range(num_modes):
                phases = [np.angle(m[mode_idx]) for m in modes_list]
                ax3.plot(phases, linewidth=1.5, marker='s', markersize=2, 
                        label=f'Mode {mode_idx}', alpha=0.6)
            ax3.set_xlabel('Step', fontweight='bold')
            ax3.set_ylabel('Phase (radians)', fontweight='bold')
            ax3.set_title('Mode Phases Over Time', fontweight='bold')
            ax3.legend(ncol=2, fontsize=8)
            ax3.grid(alpha=0.3)
        
        # Plot 4: Mode spectrum (final state)
        if modes_list:
            ax4 = plt.subplot(2, 2, 4)
            final_modes = modes_list[-1]
            amplitudes = [abs(m) for m in final_modes]
            colors_spectrum = ['#45B7D1' if a > 0.5 else '#E8F5E9' for a in amplitudes]
            ax4.bar(range(len(amplitudes)), amplitudes, color=colors_spectrum, 
                   edgecolor='black', linewidth=1.5, alpha=0.8)
            ax4.set_xlabel('Mode Index', fontweight='bold')
            ax4.set_ylabel('Final Amplitude', fontweight='bold')
            ax4.set_title('Final Mode Spectrum', fontweight='bold')
            ax4.grid(axis='y', alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Saved: {output_path}")
        plt.close()


class ComparativeAnalysis:
    """Generate comparative analysis visualizations"""
    
    @staticmethod
    def plot_model_efficiency_matrix(comparison_results: Dict[str, Dict[str, Any]], 
                                    output_path: str = '/workspace/efficiency_matrix.png'):
        """Create heatmap of model performance across different test cases"""
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        # Prepare data for heatmap
        models = list(comparison_results.keys())
        test_names = list(next(iter(comparison_results.values())).keys()) if comparison_results else []
        
        efficiency_matrix = np.zeros((len(models), len(test_names)))
        
        for m_idx, model in enumerate(models):
            for t_idx, test in enumerate(test_names):
                if test in comparison_results[model]:
                    steps = comparison_results[model][test].get('metrics', {}).get('steps', 1)
                    efficiency_matrix[m_idx, t_idx] = steps
        
        # Normalize for visualization
        if efficiency_matrix.max() > 0:
            efficiency_matrix_norm = efficiency_matrix / efficiency_matrix.max()
        else:
            efficiency_matrix_norm = efficiency_matrix
        
        im = ax.imshow(efficiency_matrix_norm, cmap='RdYlGn_r', aspect='auto')
        
        ax.set_xticks(range(len(test_names)))
        ax.set_yticks(range(len(models)))
        ax.set_xticklabels([t.replace('_', '\n') for t in test_names], fontweight='bold')
        ax.set_yticklabels(models, fontweight='bold')
        
        # Add text annotations
        for m_idx in range(len(models)):
            for t_idx in range(len(test_names)):
                value = int(efficiency_matrix[m_idx, t_idx])
                text = ax.text(t_idx, m_idx, value, ha="center", va="center",
                             color="black" if efficiency_matrix_norm[m_idx, t_idx] < 0.5 else "white",
                             fontweight='bold')
        
        ax.set_title('Model Efficiency: Steps Required Per Test\n(Lower is Better)', 
                    fontsize=14, fontweight='bold', pad=20)
        
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('Steps (normalized)', fontweight='bold')
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
        print(f"Saved: {output_path}")
        plt.close()
    
    @staticmethod
    def generate_summary_report(metrics_dict: Dict[str, ExecutionMetrics], 
                               output_path: str = '/workspace/analysis_summary.txt'):
        """Generate comprehensive text report"""
        
        report = []
        report.append("=" * 80)
        report.append("COMPUTATIONAL MODELS ANALYSIS SUMMARY")
        report.append("=" * 80)
        report.append("")
        
        total_steps = sum(m.steps for m in metrics_dict.values())
        total_time = sum(m.time_elapsed for m in metrics_dict.values())
        
        report.append("OVERALL METRICS:")
        report.append(f"  Total Steps Across All Models: {total_steps}")
        report.append(f"  Total Execution Time: {total_time*1000:.2f} ms")
        report.append(f"  Models Tested: {len(metrics_dict)}")
        report.append("")
        
        report.append("PER-MODEL ANALYSIS:")
        report.append("-" * 80)
        
        for model_name, metrics in metrics_dict.items():
            report.append(f"\n{model_name}:")
            report.append(f"  Steps: {metrics.steps}")
            report.append(f"  Time: {metrics.time_elapsed*1000:.3f} ms")
            report.append(f"  Memory Operations: {metrics.memory_accesses}")
            report.append(f"  State Transitions: {metrics.state_transitions}")
            report.append(f"  Halted: {metrics.halted}")
            report.append(f"  Output: {metrics.output}")
            
            efficiency = metrics.steps
            report.append(f"  Efficiency (steps): {efficiency:.1f}")
        
        report.append("\n" + "=" * 80)
        report.append("INSIGHTS:")
        report.append("-" * 80)
        
        min_steps_model = min(metrics_dict.items(), key=lambda x: x[1].steps)
        max_steps_model = max(metrics_dict.items(), key=lambda x: x[1].steps)
        
        report.append(f"\n✓ Most Efficient: {min_steps_model[0]} ({min_steps_model[1].steps} steps)")
        report.append(f"✗ Least Efficient: {max_steps_model[0]} ({max_steps_model[1].steps} steps)")
        
        speedup = max_steps_model[1].steps / (min_steps_model[1].steps or 1)
        report.append(f"✓ Speedup Factor: {speedup:.1f}x")
        
        report.append("\n" + "=" * 80)
        
        text = "\n".join(report)
        with open(output_path, 'w') as f:
            f.write(text)
        
        print(f"Saved: {output_path}")
        return text


def generate_all_visualizations(metrics_dict: Dict[str, ExecutionMetrics],
                               turing_trace: List[Dict] = None,
                               geometric_trace: List[Dict] = None,
                               resonance_trace: List[Dict] = None):
    """Generate all available visualizations"""
    
    print("\n" + "=" * 70)
    print("GENERATING VISUALIZATIONS")
    print("=" * 70 + "\n")
    
    visualizer = ExecutionVisualizer()
    comparative = ComparativeAnalysis()
    
    # Comparative metrics
    print("Generating step progression plot...")
    visualizer.plot_step_progression(metrics_dict)
    
    # Model-specific traces
    if turing_trace:
        print("Generating Turing machine tape evolution...")
        visualizer.plot_turing_tape_evolution(turing_trace)
    
    if geometric_trace:
        print("Generating geometric state space visualization...")
        visualizer.plot_geometric_state_space(geometric_trace)
    
    if resonance_trace:
        print("Generating resonance modes visualization...")
        visualizer.plot_resonance_modes(resonance_trace)
    
    # Summary report
    print("Generating analysis summary...")
    report = comparative.generate_summary_report(metrics_dict)
    print(report)
    
    print("\n" + "=" * 70)
    print("✓ All visualizations generated successfully!")
    print("=" * 70)


if __name__ == "__main__":
    print("Visualization module loaded")
